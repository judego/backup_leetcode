package _226翻转二叉树;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution0 solution0 = new Solution0();
        TreeNode b = new TreeNode(2);
        TreeNode a = new TreeNode(1,null, b);
        TreeNode d = solution0.invertTree(a);
        TreeNode e = new TreeNode();
    }
}
