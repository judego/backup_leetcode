package _226翻转二叉树;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public TreeNode invertTree(TreeNode root) {
        if (root != null) {
            TreeNode temp = root.left;
            root.left = invertTree(root.right);
            root.right = invertTree(temp);
        }
        return root;
    }
}
