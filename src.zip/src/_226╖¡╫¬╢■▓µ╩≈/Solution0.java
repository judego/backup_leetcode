package _226翻转二叉树;

/**
 * @author wen
 * @version 1.0
 * 写错了
 */
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode() {
    }

    TreeNode(int val) {
        this.val = val;
    }

    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}

public class Solution0 {
    public TreeNode invertTree(TreeNode root) {
        if (root == null) return root;
        change(root.left, root.right);
        return root;
    }

    public void change(TreeNode l, TreeNode r) {
        if (l == null && r == null) return;
        if (l == null) {
            l = new TreeNode(r.val);
            r = null;
        } else if (r == null) {
            r = new TreeNode(l.val);
            l = null;
        } else {
            int temp = l.val;
            l.val = r.val;
            r.val = temp;
            change(l.left, r.right);
            change(l.right, r.left);
        }
    }
}
