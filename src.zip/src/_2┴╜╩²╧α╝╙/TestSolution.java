package _2两数相加;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution1 solution1 = new Solution1();
        if (1 ==1) {
            ListNode c = new ListNode(3);
            ListNode b = new ListNode(4,c);
            ListNode a = new ListNode(2,b);
            ListNode C = new ListNode(4);
            ListNode B = new ListNode(6,C);
            ListNode A = new ListNode(5,B);
            ListNode te = solution1.addTwoNumbers(a,A);
            System.out.println(te.val);
        }
    }
}
