package _2两数相加;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        ListNode head = new ListNode();
        ListNode cur = head;
        ListNode cur1 = l1;
        ListNode cur2 = l2;
        int temp;
        boolean flag = false;
        while (!(cur1 == null && cur2 == null && flag == false)) {
            int num1 = 0;
            int num2 = 0;
            if (flag) {
                cur.next = new ListNode(1);
                flag = false;
            } else cur.next = new ListNode(0);
            cur = cur.next;
            if (cur1 != null) {
                num1 = cur1.val;
                cur1 = cur1.next;
            }
            if (cur2 != null) {
                num2 = cur2.val;
                cur2 = cur2.next;
            }
            temp = cur.val + num1 + num2;
            if (temp > 9) flag = true;
            cur.val = temp % 10;
        }
        return head.next;
    }
}
