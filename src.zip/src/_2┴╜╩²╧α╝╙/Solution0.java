package _2两数相加;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        return writeListNode(readListNode(l1) + readListNode(l2));
    }

    public int readListNode(ListNode node) {
        int num = 0;
        ListNode cur = node;
        int i = 0;
        while (cur != null) {
            num += cur.val * (int) (Math.pow(10, i));
            cur = cur.next;
            i++;
        }
        return num;
    }

    public ListNode writeListNode(int num) {
        ListNode head = new ListNode(num % 10);
        ListNode cur = head;
        while (num != 0) {
            ListNode temp = new ListNode(num % 10);
            cur.next = temp;
            cur = temp;
            num /= 10;
        }
        if (head.val == 0 && head.next == null) return head;
        return head.next;
    }
}

class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}

