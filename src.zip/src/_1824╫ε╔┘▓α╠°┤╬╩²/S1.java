package _1824最少侧跳次数;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int minSideJumps(int[] obstacles) {
        int[] convert = {0b111, 0b011, 0b101, 0b110};
        int res = 0, now, rec = 0b010;
        for (int i = 1; i < obstacles.length; i++) {
            now = convert[obstacles[i]];
            rec &= now;
            if (rec == 0) {
                res++;
                rec = (now & convert[obstacles[i - 1]]);
            }
        }
        return res;
    }
}
