package _1824最少侧跳次数;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int minSideJumps(int[] obstacles) {
        int[] dp = {1, 0, 1};
        final int INF = 10000000;
        for (int i = 1; i < obstacles.length; i++) {
            int min = INF;
            for (int j = 0; j < 3; j++) {
                if (j == obstacles[i] - 1) {
                    dp[j] = INF;
                } else min = Math.min(min, dp[j]);
            }
            for (int j = 0; j < 3; j++) {
                if (j != obstacles[i] - 1) {
                    dp[j] = Math.min(min + 1, dp[j]);
                }
            }
        }
        return Math.min(dp[0], Math.min(dp[1], dp[2]));
    }
}
