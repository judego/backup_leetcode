package _350两个数组的交集II;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        int[] a = {1, 2, 2, 1};
        int[] b = {2, 2};
        Solution0 solution0 = new Solution0();
        int[] c = solution0.intersect(a, b);
    }
}
