package _350两个数组的交集II;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int[] intersect(int[] nums1, int[] nums2) {
        int cur1 = 0, cur2 = 0, cur3 = 0;
        int[] temp = new int[Math.min(nums1.length, nums2.length)];
        Arrays.sort(nums1);
        Arrays.sort(nums2);
        while (!(cur1 == nums1.length || cur2 == nums2.length)) {
            if (nums1[cur1] > nums2[cur2]) {
                cur2++;
            } else if (nums1[cur1] < nums2[cur2]) {
                cur1++;
            } else {
                temp[cur3] = nums1[cur1];
                cur3++;
                cur1++;
                cur2++;
            }
        }
        return Arrays.copyOfRange(temp,0,cur3);
    }
}
