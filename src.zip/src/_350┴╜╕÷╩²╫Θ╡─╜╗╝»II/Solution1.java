package _350两个数组的交集II;

import java.util.Arrays;
import java.util.HashMap;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int[] intersect(int[] nums1, int[] nums2) {
        if (nums1.length > nums2.length) return intersect(nums2, nums1);
        int[] res = new int[nums1.length];
        HashMap<Integer, Integer> hm = new HashMap<>();
        for (int i = 0; i < nums1.length; i++) {
            hm.put(nums1[i], hm.getOrDefault(nums1[i], 0) + 1);
        }
        int count = 0;
        for (int i = 0; i < nums2.length; i++) {
            if (hm.containsKey(nums2[i])) {
                hm.put(nums2[i], hm.get(nums2[i]) - 1);
                if (hm.get(nums2[i]) == 0) hm.remove(nums2[i]);
                res[count++] = nums2[i];
            }
        }
        return Arrays.copyOfRange(res, 0, count);
    }
}
