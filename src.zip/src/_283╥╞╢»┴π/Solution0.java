package _283移动零;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public void moveZeroes(int[] nums) {
        int pre = 0;
        int lat = 0;
        boolean isEmpty = true;
        while (true) {
            if (nums[lat] != 0) {
                nums[pre] = nums[lat];
                lat++;
                isEmpty = false;
            } else {
                lat++;
            }
            if (!(isEmpty)) {
                pre++;
                isEmpty = true;
            }
            if (lat == nums.length) break;
        }
        while (pre < nums.length) {
            nums[pre] = 0;
            pre++;
        }
    }
}
