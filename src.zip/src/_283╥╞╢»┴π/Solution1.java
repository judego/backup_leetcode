package _283移动零;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public void moveZeroes(int[] nums) {
        int pre = 0,lat = 0;
        for (boolean isEmpty = true; lat != nums.length; lat++) {
            if (nums[lat] != 0) {
                nums[pre] = nums[lat];
                isEmpty = false;
            }
            if (!(isEmpty)) {
                pre++;
                isEmpty = true;
            }
        }
        while (pre < nums.length) {
            nums[pre] = 0;
            pre++;
        }
    }
}
