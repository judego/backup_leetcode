package _283移动零;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        int[] arr = {0, 0, 0, 0, -25503, 20486, -94356, 0, -20253, 80325, 0,
                62558, -41932, -63525, 0, 0, 0, 0, 0, -16051, -896, 0, -7783,
                0, 0, -26335, 19267, -33350, 0, 73475, 0, 82325, 68084, -60140,
                0, 78072, 98839, 0, 0, -83121, 0, -32293, 16421, 48223, 0,
                -8846, 73852, -48827, 12788, -68476, 0, 0};
        Solution1 solution0 = new Solution1();
        solution0.moveZeroes(arr);
    }
}
