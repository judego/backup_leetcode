package _55跳跃游戏;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public boolean canJump(int[] nums) {
        int l = 0;
        for (int r = 0; l < nums.length - 1; l++) {
            r = Math.max(r, l + nums[l]);
            if (l == r) return false;
        }
        return true;
    }
}
