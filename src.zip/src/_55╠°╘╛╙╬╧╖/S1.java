package _55跳跃游戏;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public boolean canJump(int[] nums) {
        int i = nums.length - 2;
        int j = nums.length - 1;
        while (true) {
            if (j == 0) {
                return true;
            }
            if (i == -1) {
                return false;
            }
            if (j - i <= nums[i]) {
                j = i;
            }
            i--;
        }
    }
}
