package _217存在重复元素;

import _217存在重复元素.Solution;

/**
 * @author wen
 * @version 1.0
 */
public class Main {
    public static void main(String[] args) {
        Solution solution = new Solution();
        int[] arr = {1,2,4,4,5};
        System.out.println(solution.containsDuplicate(arr));;
    }
}