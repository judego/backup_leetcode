package _217存在重复元素;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public boolean containsDuplicate(int[] nums) {
        Arrays.sort(nums);
        for (int i = 0; i < nums.length - 1; i++) {
            if (nums[i] - nums[i + 1] == 0) {
                return true;
            }
        }
        return false;
    }
}
