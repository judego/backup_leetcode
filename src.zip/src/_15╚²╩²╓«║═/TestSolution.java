package _15三数之和;

import java.util.HashSet;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution1 solution0 = new Solution1();
        int[] arr = {-2,-3,0,0,-2};
        List<List<Integer>> d = solution0.threeSum(arr);
    }
}
