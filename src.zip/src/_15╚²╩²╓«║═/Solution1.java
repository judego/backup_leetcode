package _15三数之和;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public List<List<Integer>> threeSum(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> res = new ArrayList<>();
        int p1 = 0;
        while (p1 < nums.length - 2 && nums[p1] <= 0) {
            if (p1 > 0 && nums[p1] == nums[p1 - 1]) {
                p1++;
                continue;
            }
            int p2 = p1 + 1, p3 = nums.length - 1, temp;
            while (p3 > p2 && nums[p3] >= 0) {
                temp = nums[p1] + nums[p2] + nums[p3];
                if (temp > 0) {
                    p3--;
                } else if (temp < 0) {
                    p2++;
                } else {
                    List<Integer> c = new ArrayList<>();
                    c.add(nums[p1]);
                    c.add(nums[p2]);
                    c.add(nums[p3]);
                    res.add(c);
                    p2++;
                    while (p2 < p3 && nums[p2] == nums[p2 - 1]) p2++;
                    p3--;
                    while (p2 < p3 && nums[p3] == nums[p3 + 1]) p3--;
                }
            }
            p1++;
        }
        return res;
    }
}
