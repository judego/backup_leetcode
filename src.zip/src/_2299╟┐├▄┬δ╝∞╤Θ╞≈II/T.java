package _2299强密码检验器II;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        boolean res = s0.strongPasswordCheckerII("aA0!bB1@@3rbHkB8Puvl");
    }
}
