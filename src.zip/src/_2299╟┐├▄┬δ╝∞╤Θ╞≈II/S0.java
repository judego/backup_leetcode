package _2299强密码检验器II;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public boolean strongPasswordCheckerII(String password) {
        if (password.length() < 8) return false;
        boolean flag1 = false, flag2 = false, flag3 = false, flag4 = false, flag5 = false;
        char temp = '好';
        for (char c : password.toCharArray()) {
            if (c == temp) return false;
            temp = c;
            if (!flag5) {
                if (c <= 'z' && c >= 'a') flag1 = true;
                else if (c <= 'Z' && c >= 'A') flag2 = true;
                else if (c <= '9' && c >= '0') flag3 = true;
                else if (c == '!' || c == '@' || c == '#' || c == '$' || c == '%' ||
                        c == '^' || c == '&' || c == '*' || c == '(' || c == ')' ||
                        c == '-' || c == '+') flag4 = true;
            }
            if (flag1 && flag2 && flag3 && flag4) flag5 = true;
        }
        return flag5;
    }
}
