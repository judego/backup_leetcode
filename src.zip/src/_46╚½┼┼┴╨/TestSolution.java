package _46全排列;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution0 solution0 = new Solution0();
        int[] nums = {1, 2, 3};
        List<List<Integer>> d = solution0.permute(nums);
    }
}
