package _46全排列;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public List<List<Integer>> permute(int[] nums) {
        List<List<Integer>> res = new ArrayList<>();
        boolean[] used = new boolean[nums.length];
        dfs(res, new ArrayList<>(), nums, used);
        return res;
    }

    public void dfs(List<List<Integer>> res, ArrayList<Integer> list, int[] nums, boolean[] used) {
        if (list.size() == nums.length) {
            res.add(new ArrayList<>(list));
            return;
        }
        for (int i = 0; i < nums.length; i++) {
            if (used[i] == true) {
                continue;
            }
            list.add(nums[i]);
            used[i] = true;
            dfs(res, list, nums, used);
            used[i] = false;
            list.remove(list.size() - 1);
        }
    }
}
