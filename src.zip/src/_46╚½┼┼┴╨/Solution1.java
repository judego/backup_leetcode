package _46全排列;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
}
