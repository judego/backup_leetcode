package _1945字符串转化后的各位数字之和;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.getLucky("leetcode", 2);
    }
}
