package _1945字符串转化后的各位数字之和;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
}
