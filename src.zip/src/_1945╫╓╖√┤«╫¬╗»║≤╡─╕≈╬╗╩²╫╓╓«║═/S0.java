package _1945字符串转化后的各位数字之和;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int getLucky(String s, int k) {
        int res = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) < 106) res += s.charAt(i) - 96;
            else if (s.charAt(i) < 116) res += s.charAt(i) - 10;
            else res += s.charAt(i) - 114;
        }
        for (int i = 1; i < k; i++) {
            int temp = 0;
            while (res != 0) {
                temp += res % 10;
                res /= 10;
            }
            res = temp;
        }
        return res;
    }
}
