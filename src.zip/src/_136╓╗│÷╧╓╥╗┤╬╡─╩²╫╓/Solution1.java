package _136只出现一次的数字;

import java.util.ArrayList;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public static int singleNumber(int[] nums) {
        int ans = nums[0];
        if (nums.length > 1) {
            for (int i = 1; i < nums.length; i++) {
                ans = ans ^ nums[i];
            }
        }
        return ans;
    }
}
