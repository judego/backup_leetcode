package _136只出现一次的数字;

import java.util.ArrayList;

/**
 * @author wen
 * @version 1.0
 */
public class Solution {
    public static int singleNumber(int[] nums) {
        ArrayList<Integer> arr = new ArrayList<>(nums.length / 2 + 1);
        for (int i = 0; i < nums.length; i++) {
            if (arr.indexOf((Integer) nums[i]) == -1) {
                arr.add((Integer) nums[i]);
            }else {
                arr.remove((Integer) nums[i]);
            }
        }
        return arr.get(0);
    }
}
