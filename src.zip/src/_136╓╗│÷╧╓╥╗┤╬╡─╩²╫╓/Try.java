package _136只出现一次的数字;

import _20有效地括号.Solution2;

/**
 * @author wen
 * @version 1.0
 */
public class Try {
    public static void main(String[] args) {
        int[] ints = {1,2,2,3,3,4,5,5,4};
        System.out.println(Solution1.singleNumber(ints));
    }
}
