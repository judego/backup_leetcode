package _1233删除子文件夹;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        String[] a = {"/a","/a/b","/c/d","/c/d/e","/c/f"};
        List<String> list = new S1(){}.removeSubfolders(a);
    }
}
