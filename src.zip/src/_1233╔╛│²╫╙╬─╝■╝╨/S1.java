package _1233删除子文件夹;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public List<String> removeSubfolders(String[] folder) {
        List<String> res = new LinkedList<>();
        Arrays.sort(folder);
        String check = "";
        int len = 101;
        for (String s : folder) {
            if (s.length() <= len || !s.substring(0, len).equals(check) || s.charAt(len) != '/') {
                check = s;
                len = s.length();
                res.add(s);
            }
        }
        return res;
    }
}
