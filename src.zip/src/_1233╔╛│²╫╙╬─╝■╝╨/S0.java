package _1233删除子文件夹;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public List<String> removeSubfolders(String[] folder) {
        List<String> res = new LinkedList<>();
        Arrays.sort(folder);
        char[] check = folder[0].toCharArray();
        for (String s : folder) {
            char[] cs = s.toCharArray();
            if (cs.length > check.length) {
                int i = 0;
                while (i < check.length)
                    if (check[i] != cs[i++]) i = Integer.MAX_VALUE;
                if (i == check.length && cs[i] == '/') continue;
            }
            check = s.toCharArray();
            res.add(s);
        }
        return res;
    }
}
