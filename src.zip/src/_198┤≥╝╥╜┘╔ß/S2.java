package _198打家劫舍;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int rob(int[] nums) {
        int cur = 0, pre = 0;
        for (int num : nums) {
            int temp = Math.max(cur, pre + num);
            pre = cur;
            cur = temp;
        }
        return cur;
    }
}
