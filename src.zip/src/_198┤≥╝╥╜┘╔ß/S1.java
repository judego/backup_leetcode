package _198打家劫舍;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int rob(int[] nums) {
        int[] arr = new int[4];
        byte index = 0;
        for (int num : nums) {
            arr[index % 4] = Math.max(arr[(index + 1) % 4], arr[(index + 2) % 4]) + num;
            index++;
        }
        return Math.max(arr[(index + 2) % 4], arr[(index + 3) % 4]);
    }
}
