package _198打家劫舍;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S1 s0 = new S1();
        int[] arr = {1,2,3,1};
        int a = s0.rob(arr);
    }
}
