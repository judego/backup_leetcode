package _2287重排字符形成目标字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int rearrangeCharacters(String s, String target) {
        int[] a = new int[26];
        int[] b = new int[26];
        for (int i = 0; i < s.length(); i++) a[s.charAt(i) - 'a']++;
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < target.length(); i++) b[target.charAt(i) - 'a']++;
        for (int i = 0; i < b.length; i++) if (b[i] != 0) min = Math.min(min, a[i] / b[i]);
        return min;
    }
}
