package _2287重排字符形成目标字符串;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.rearrangeCharacters("ilovecodingonleetcode","code");
    }
}
