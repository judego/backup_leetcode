package _2287重排字符形成目标字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int rearrangeCharacters(String s, String target) {
        int[] a = new int[26];
        int[] b = new int[26];
        char[] c = s.toCharArray();
        char[] d = target.toCharArray();
        for (char c1 : c) {
            a[c1 - 'a']++;
        }
        int min = Integer.MAX_VALUE;
        for (char c1 : d) {
            b[c1 - 'a']++;
        }
        for (int i = 0; i < b.length; i++) {
            if (b[i] != 0) min = Math.min(min, a[i] / b[i]);
        }
        return min;
    }
}
