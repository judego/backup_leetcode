package _2319判断矩阵是否是一个X矩阵;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {

    }
}
