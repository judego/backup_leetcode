package _2283判断一个数的数字计数是否等于数位的值;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        boolean a = s0.digitCount("1201");
    }
}
