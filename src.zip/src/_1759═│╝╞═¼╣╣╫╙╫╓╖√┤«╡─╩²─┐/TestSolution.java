package _1759统计同构子字符串的数目;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.countHomogenous("abbcccaa");
    }
}
