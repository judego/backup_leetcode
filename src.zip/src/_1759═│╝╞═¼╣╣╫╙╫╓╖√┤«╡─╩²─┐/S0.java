package _1759统计同构子字符串的数目;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int countHomogenous(String s) {
        long res = 0;
        int count = 0;
        char[] arr = s.toCharArray();
        for (int i = 0; i < arr.length; i++) {
            if (count == 0 || arr[i] == arr[i - 1]) count++;
            else {
                res += (long) (count + 1) * count / 2;
                count = 1;
            }
        }
        res += (long) (count + 1) * count / 2;
        return (int) (res % 1000000007);
    }
}
