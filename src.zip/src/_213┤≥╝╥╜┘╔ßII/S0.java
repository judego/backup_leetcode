package _213打家劫舍II;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int rob(int[] nums) {
        if (nums.length == 1) return nums[0];
        int cur1 = 0, cur2 = 0;
        for (int i = 0, pre = 0; i < nums.length - 1; i++) {
            int temp = Math.max(cur1, pre + nums[i]);
            pre = cur1;
            cur1 = temp;
        }
        for (int i = 1, pre = 0; i < nums.length; i++) {
            int temp = Math.max(cur2, pre + nums[i]);
            pre = cur2;
            cur2 = temp;
        }
        return Math.max(cur1, cur2);
    }
}
