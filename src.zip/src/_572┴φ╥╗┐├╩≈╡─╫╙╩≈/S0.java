package _572另一棵树的子树;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    boolean flag = false;
    TreeNode subRoot;

    public boolean isSubtree(TreeNode root, TreeNode subRoot) {
        this.subRoot = subRoot;
        dfs(root);
        return flag;
    }

    public void dfs(TreeNode root) {
        if (root == null) return;
        if (isSame(root, subRoot)) {
            flag = true;
            return;
        }
        dfs(root.left);
        dfs(root.right);
    }

    public boolean isSame(TreeNode root, TreeNode subRoot) {
        if (subRoot == null && root == null) return true;
        if (subRoot == null || root == null) return false;
        if (root.val != subRoot.val) return false;
        return isSame(root.left, subRoot.left) && isSame(root.right, subRoot.right);
    }
}
