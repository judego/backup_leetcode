package _572另一棵树的子树;

/**
 * @author wen
 * @version 1.0
 */
public class S3 {
    public boolean isSubtree(TreeNode root, TreeNode subRoot) {
        boolean flag = false;
        if (root == null && subRoot == null) return true;
        else if (root == null || subRoot == null) return false;
        else if (root.val == subRoot.val) flag = isSame(root.left, subRoot.left) && isSame(root.right, subRoot.right);
        return flag || isSubtree(root.left, subRoot) || isSubtree(root.right, subRoot);
    }

    public boolean isSame(TreeNode root, TreeNode subRoot) {
        if (subRoot == null && root == null) return true;
        else if (subRoot == null || root == null || root.val != subRoot.val) return false;
        return isSame(root.left, subRoot.left) && isSame(root.right, subRoot.right);
    }
}
