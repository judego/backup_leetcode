package _59螺旋矩阵II;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[][] res = s0.generateMatrix(4);
    }
}
