package _59螺旋矩阵II;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int[][] generateMatrix(int n) {
        int[][] res = new int[n][n];
        int x = 0, y = 0, direct = 0;
        boolean changeDirect;
        for (int i = 1; i <= n * n; i++) {
            res[x][y] = i;
            changeDirect = direct % 4 == 0 && (y == n - 1 || res[x][y + 1] != 0)
                    || direct % 4 == 1 && (x == n - 1 || res[x + 1][y] != 0)
                    || direct % 4 == 2 && (y == 0 || res[x][y - 1] != 0)
                    || direct % 4 == 3 && (x == 0 || res[x - 1][y] != 0);
            if (changeDirect) direct++;
            switch (direct % 4) {
                case 0:
                    y++;
                    break;
                case 1:
                    x++;
                    break;
                case 2:
                    y--;
                    break;
                case 3:
                    x--;
            }
        }
        return res;
    }
}
