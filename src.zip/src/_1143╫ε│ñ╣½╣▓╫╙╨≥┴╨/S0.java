package _1143最长公共子序列;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
}
