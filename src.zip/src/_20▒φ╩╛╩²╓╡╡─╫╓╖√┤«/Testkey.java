package _20表示数值的字符串;

/**
 * @author wen
 * @version 1.0
 */
public class Testkey {
    public static void main(String[] args) {
        Solution solution = new Solution();
        System.out.println(solution.isNumber(" "));
        String s = " asd ";
    }
}
