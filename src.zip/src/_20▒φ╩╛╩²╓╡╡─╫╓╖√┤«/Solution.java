package _20表示数值的字符串;

/**
 * @author wen
 * @version 1.0
 */
public class Solution {
    public boolean isNumber(String s) {
        StringBuffer sb = new StringBuffer();
        String a = "";
        String b = "";
        for (int i = 0; i < s.length(); i++) {
            char z = s.charAt(i);
            if (z == 32 || z == 43 || z == 45 || z == 46 || z == 69 || z == 101 ||
                    (z >= 48 && z <= 57)) {
                sb.append(z);
            } else {
                return false;
            }
        }
        //去空格
        while (sb.length() != 0 && sb.charAt(0) == 32) {
            sb.deleteCharAt(0);
        }
        while (sb.length() != 0 && sb.charAt(sb.length() - 1) == 32) {
            sb.deleteCharAt(sb.length() - 1);
        }
        //
        if (sb.length() == 0) {
            return false;
        }
        //检查第二点，小数或者整数
        if (sb.charAt(0) == 43 || sb.charAt(0) == 45) {
            sb.deleteCharAt(0);
        }
        int eIndex = isE(sb);
        if (eIndex != -1) {
            if (sb.length() > eIndex + 1) {
                a = sb.substring(0, eIndex);
                b = sb.substring(eIndex + 1);
            } else {
                return false;
            }
        } else {
            a = sb.substring(0);
        }
        //
        if (b.length() != 0) {
            if (!(isInt(b))) {
                return false;
            }
        }
        if (a.length() == 0) {
            return false;
        }
        if (!(isInt(a) || isDecimal(a))) {
            return false;
        }
        return true;
    }


    public boolean isInt(String s) {
        if (s.charAt(0) == 43 || s.charAt(0) == 45) {
            s = s.substring(1);
        }
        if (s.length() < 1) {
            return false;
        }
        for (int i = 0; i < s.length(); i++) {
            if (!(s.charAt(i) >= 48 && s.charAt(i) <= 57)) {
                return false;
            }
        }
        return true;
    }

    public boolean isDecimal(String s) {
        if (s.charAt(0) == 43 || s.charAt(0) == 45) {
            s = s.substring(1);
        }
        if (s.length() < 2) {
            return false;
        }
        int pointNum = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == 46) {
                pointNum++;
            } else if ((s.charAt(i) >= 48 && s.charAt(i) <= 57)) {
            } else {
                return false;
            }
        }
        if (pointNum != 1) {
            return false;
        }
        return true;
    }

    public int isE(StringBuffer sb) {
        for (int i = 0; i < sb.length(); i++) {
            if (sb.charAt(i) == 69 || sb.charAt(i) == 101) {
                return i;
            }
        }
        return -1;
    }
}
