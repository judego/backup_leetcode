package _2180统计各位数字之和为偶数的整数个数;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int countEven(int num) {
        boolean[] check = new boolean[num + 1];//false代表不符合
        int n = Math.min(num + 1, 10);
        for (int i = 1; i < n; i++) {
            if (i % 2 == 0) check[i] = true;
        }
        for (int i = 10; i < num + 1; i++) {
            if ((check[i / 10] && i % 2 == 0) || (!check[i / 10] && i % 2 == 1)) check[i] = true;
        }
        n = 0;
        for (boolean b : check) {
            if (b) n++;
        }
        return n;
    }
}
