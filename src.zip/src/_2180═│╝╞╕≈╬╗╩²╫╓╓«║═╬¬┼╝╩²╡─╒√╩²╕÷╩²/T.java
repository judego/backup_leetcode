package _2180统计各位数字之和为偶数的整数个数;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] res = new int[1001];
        for (int i = 1; i < 1001; i++) {
            res[i] = s0.countEven(i);
        }
        for (int i = 0; i < 1001; i++) {
            System.out.printf(res[i] + ",");
            if (i % 20 == 0) System.out.println("");
        }
        S2 s2 = new S2();
        int a = s2.countEven(4);
    }
}
