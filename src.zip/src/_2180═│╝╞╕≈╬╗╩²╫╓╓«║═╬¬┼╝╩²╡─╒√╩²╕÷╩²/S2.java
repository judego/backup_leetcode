package _2180统计各位数字之和为偶数的整数个数;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int countEven(int num) {
        if (((num / 1000 + num / 100 + num / 10 + num) & 1) == 1) num -= 1;
        return num >> 1;
    }
}
