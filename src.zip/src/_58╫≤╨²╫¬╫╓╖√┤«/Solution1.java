package _58左旋转字符串;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public String reverseLeftWords(String s, int n) {
        return s.substring(n, s.length()) + s.substring(0, n);
    }
}
