package _143重排链表;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}

public class S0 {
    public void reorderList(ListNode head) {
        if (head == null || head.next == null || head.next.next == null) return;
        ListNode temp1 = head.next;
        while (temp1.next.next != null) temp1 = temp1.next;
        ListNode last = temp1.next, temp2 = head.next;
        temp1.next = null;
        head.next = last;
        last.next = temp2;
        reorderList(temp2);
    }
}
