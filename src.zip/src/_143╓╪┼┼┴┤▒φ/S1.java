package _143重排链表;

import java.util.List;
import java.util.concurrent.TransferQueue;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public void reorderList(ListNode head) {
        if (head == null || head.next == null || head.next.next == null) return;
        ListNode link1 = head.next, temp = findMiddle(head),
                link2 = reverse(temp.next), cur = head;
        temp.next = null;
        while (link1 != null) {
            ListNode temp1 = link1.next, temp2 = link2.next;
            cur.next = link2;
            cur = cur.next;
            cur.next = link1;
            cur = cur.next;
            link1 = temp1;
            link2 = temp2;
        }
        if (link2 != null) cur.next = link2;
    }

    public ListNode findMiddle(ListNode head) {
        ListNode l = head, f = l;
        while (!(f.next == null || f.next.next == null)) {
            f = f.next.next;
            l = l.next;
        }
        return l;
    }

    public ListNode reverse(ListNode head) {
        ListNode res = null, cur = head;
        while (cur != null) {
            ListNode temp = cur.next;
            cur.next = res;
            res = cur;
            cur = temp;
        }
        return res;
    }
}
