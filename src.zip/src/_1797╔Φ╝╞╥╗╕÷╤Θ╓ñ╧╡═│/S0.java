package _1797设计一个验证系统;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
}

class AuthenticationManager {
    int timeToLive;
    HashMap<String, Integer> mp = new HashMap<>();

    public AuthenticationManager(int timeToLive) {
        this.timeToLive = timeToLive;
    }

    public void generate(String tokenId, int currentTime) {
        mp.put(tokenId, currentTime + timeToLive);
    }

    public void renew(String tokenId, int currentTime) {
        if (mp.getOrDefault(tokenId, 0) > currentTime)
            mp.put(tokenId, currentTime + timeToLive);
    }

    public int countUnexpiredTokens(int currentTime) {
        int res = 0;
        for (Integer time : mp.values()) if (time > currentTime) res++;
        return res;
    }
}
