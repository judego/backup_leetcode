package _1797设计一个验证系统;

import java.util.LinkedList;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        AuthenticationManager a = new AuthenticationManager(13);
        a.renew("ajvy",1);
        a.countUnexpiredTokens(3);
        a.countUnexpiredTokens(4);
        a.generate("fuzxq",5);
        a.generate("izmry",7);
        a.renew("puv",12);
        a.generate("ybiqb",13);
        a.generate("gm",14);
        a.countUnexpiredTokens(15);
        a.countUnexpiredTokens(18);
        a.countUnexpiredTokens(19);
        a.renew("ybiqb",21);
        a.countUnexpiredTokens(23);
        a.countUnexpiredTokens(25);
        a.countUnexpiredTokens(26);
        a.generate("aqdm",28);
        a.countUnexpiredTokens(29);
        a.renew("puv",30);
    }
}
