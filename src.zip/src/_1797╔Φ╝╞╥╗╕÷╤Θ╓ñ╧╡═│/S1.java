package _1797设计一个验证系统;


/**
 * @author wen
 * @version 1.0
 */
public class S1 {
}
