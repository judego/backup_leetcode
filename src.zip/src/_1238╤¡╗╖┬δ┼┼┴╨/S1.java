package _1238循环码排列;

import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public List<Integer> circularPermutation(int n, int start) {
        Integer[] res = new Integer[1 << n];
        int cur = -1;
        while (cur < res.length - 1) {
            res[++cur] = cur ^ (cur >> 1) ^ start;
        }
        return Arrays.asList(res);
    }
}
