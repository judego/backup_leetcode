package _1238循环码排列;

import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public List<Integer> circularPermutation(int n, int start) {
        Integer[] res = new Integer[1 << n];
        res[0] = start;
        for (int i = 0, cur = 1, temp = 1; i < n; i++, temp <<= 1) {
            for (int j = cur - 1; j >= 0; j--, cur++) {
                res[cur] = res[j] ^ temp;
            }
        }
        return Arrays.asList(res);
    }
}
