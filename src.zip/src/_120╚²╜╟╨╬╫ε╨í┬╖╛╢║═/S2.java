package _120三角形最小路径和;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int minimumTotal(List<List<Integer>> triangle) {
        int n = triangle.size();
        int[][] f = new int[1][n];
        f[0][0] = triangle.get(0).get(0);
        for (int i = 1; i < n; i++) {
            f[0][i] = f[0][i - 1] + triangle.get(i).get(i);
            for (int j = i - 1; j > 0; j--) {
                f[0][j] = Math.min(f[0][j - 1],
                        f[0][j]) + triangle.get(i).get(j);
            }
            f[0][0] += triangle.get(i).get(0);
        }
        int res = f[0][0];
        for (int i = 1; i < n; i++) {
            res = Math.min(res, f[0][i]);
        }
        return res;
    }
}
