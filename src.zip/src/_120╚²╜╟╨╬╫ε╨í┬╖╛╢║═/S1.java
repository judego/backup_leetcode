package _120三角形最小路径和;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int minimumTotal(List<List<Integer>> triangle) {
        int n = triangle.size();
        int[][] f = new int[2][n];
        f[0][0] = triangle.get(0).get(0);
        for (int i = 1; i < n; i++) {
            f[i % 2][0] = f[(i - 1) % 2][0] + triangle.get(i).get(0);
            for (int j = 1; j < i; j++) {
                f[i % 2][j] = Math.min(f[(i - 1) % 2][j - 1], f[(i - 1) % 2][j])
                        + triangle.get(i).get(j);
            }
            f[i % 2][i] = f[(i - 1) % 2][i - 1] + triangle.get(i).get(i);
        }
        int res = f[(n - 1) % 2][n - 1];
        for (int i = 0; i < n - 1; i++) {
            res = Math.min(res, f[(n - 1) % 2][i]);
        }
        return res;
    }
}
