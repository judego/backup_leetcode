package _120三角形最小路径和;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S3 {
    public int minimumTotal(List<List<Integer>> triangle) {
        int[] f = new int[triangle.size() + 1];
        for (int i = triangle.size() - 1; i >= 0; i--) {
            for (int j = 0; j <= i; j++) {
                f[j] = Math.min(f[j], f[j + 1]) + triangle.get(i).get(j);
            }
        }
        return f[0];
    }
}
