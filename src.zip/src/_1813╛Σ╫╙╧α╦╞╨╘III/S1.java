package _1813句子相似性III;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public boolean areSentencesSimilar(String sentence1, String sentence2) {
        if (sentence1.length() > sentence2.length()) return areSentencesSimilar(sentence2, sentence1);
        String[] s1 = sentence1.split(" "), s2 = sentence2.split(" ");
        int l = 0, r = s1.length - 1, i = s2.length - 1;
        while (l < s1.length){
            if (!s1[l].equals(s2[l])) break;
            l++;
        }
        while (r >= l){
            if (!s1[r].equals(s2[i])) break;
            i--;
            r--;
        }
        return l > r;
    }
}
