package _1813句子相似性III;

/**
 * @author wen
 * @version 1.0
 * 不行
 */
public class S0 {
    public boolean areSentencesSimilar(String sentence1, String sentence2) {
        if (sentence1.length() > sentence2.length()) return areSentencesSimilar(sentence2, sentence1);
        int len1 = sentence1.length(), len2 = sentence2.length(), l1 = 0, r1 = len1 - 1, l2 = l1, r2 = r1;
        char[] s1 = sentence1.toCharArray(), s2 = sentence2.toCharArray();
        while (l1 < len1 && s1[l1] == s2[l1]) {
            if (s2[l1] == ' ' || l1 == len1 - 1) l2 = l1;
            l1++;
        }
        for (int i = len2 - 1; r1 >= l2 && s1[r1] == s2[i]; i--, r1--) {
            if (s2[i] == ' ' || r1 == 0) r2 = r1;
        }
        return l2 >= r2;
    }
}
