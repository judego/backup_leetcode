package _1813句子相似性III;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S1 s0 = new S1();
        boolean a = s0.areSentencesSimilar("xD iP tqchblXgqvNVdi"
                , "FmtdCzv Gp YZf UYJ xD iP tqchblXgqvNVdi"
        );
    }
}
