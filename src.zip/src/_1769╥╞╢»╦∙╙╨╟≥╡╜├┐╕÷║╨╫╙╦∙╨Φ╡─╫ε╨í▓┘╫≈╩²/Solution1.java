package _1769移动所有球到每个盒子所需的最小操作数;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int[] minOperations(String boxes) {
        int number_sum = 0, temp = 0;
        int[] res = new int[boxes.length()];
        for (int i = 0; i < boxes.length(); i++) {
            if (boxes.charAt(i) == '1') {
                temp += i;
                number_sum++;
            }
        }
        int number_right = number_sum - (boxes.charAt(0) == '0' ? 0 : 1);
        res[0] = temp;
        for (int i = 1; i < res.length; i++) {
            temp += number_sum - 2 * number_right;
            res[i] = temp;
            if (boxes.charAt(i) == '1') number_right--;
        }
        return res;
    }
}
