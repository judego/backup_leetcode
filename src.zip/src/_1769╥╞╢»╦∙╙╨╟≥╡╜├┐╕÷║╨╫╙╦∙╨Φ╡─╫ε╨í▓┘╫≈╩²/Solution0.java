package _1769移动所有球到每个盒子所需的最小操作数;

/**
 * @author wen
 * @version 1.0
 * 先来个暴力解法
 */
public class Solution0 {
    public int[] minOperations(String boxes) {
        int number_sum = 0, temp = 0;
        int[] res = new int[boxes.length()];
        for (int i = 0; i < boxes.length(); i++) {
            if (boxes.charAt(i) == '1') {
                temp += i;
                number_sum++;
            }
        }
        for (int i = 0, number_right = number_sum; i < res.length; i++) {
            if (i == 0) {
                if (boxes.charAt(0) == '0') {
                    number_right = number_sum;
                } else number_right = number_sum - 1;
            }
            if (i != 0 && boxes.charAt(i) == '1') {
                temp += number_sum - 2 * number_right;
                number_right--;
            } else if (i != 0 && boxes.charAt(i) == '0') {
                temp += number_sum - 2 * number_right;
            }
            res[i] = temp;
        }
        return res;
    }
}
