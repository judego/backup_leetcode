package _1769移动所有球到每个盒子所需的最小操作数;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        String a = "110";
        Solution0 solution0 = new Solution0();
        int[] b = solution0.minOperations(a);
    }
}
