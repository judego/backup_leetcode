package _242有效的字母异位词;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public boolean isAnagram(String s, String t) {
        if (s.length() != t.length()) return false;
        char[] a = s.toCharArray();
        char[] b = t.toCharArray();
        Arrays.sort(a);
        Arrays.sort(b);
        return Arrays.equals(a, b);
    }
}
