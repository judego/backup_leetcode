package _2027转换字符串的最少操作次数;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int minimumMoves(String s) {
        int p = 0, count = 0, n = s.length();
        while (p < n) {
            if (s.charAt(p) == 88) {
                p += 3;
                count++;
            } else p++;
        }
        return count;
    }
}
