package _30包含min函数的栈;

/**
 * @author wen
 * @version 1.0
 */
public class Tes {
    public static void main(String[] args) {
        MinStack a = new MinStack();
        a.push(-2);
        a.push(0);
        a.push(-1);
        System.out.println(a.getMin());
        a.top();
        a.pop();
        a.getMin();
    }
}
