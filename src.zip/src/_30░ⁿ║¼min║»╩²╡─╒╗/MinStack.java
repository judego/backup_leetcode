package _30包含min函数的栈;

import java.util.Stack;

/**
 * @author wen
 * @version 1.0
 */
class MinStack {
    Stack<Integer> a;
    public static int min_index = -1;
    public static int min;

    public MinStack() {
        a = new Stack<>();
    }

    public void push(int x) {
        if (a.isEmpty()) {
            min = x;
            min_index = 0;
        } else if (x < min) {
            min = x;
            min_index = a.size();
        }
        a.push(x);
    }

    public void pop() {
        if (a.peek().equals(min) && a.size() > 1) {
            a.pop();
            Integer[] arr = new Integer[a.size()];
            a.toArray(arr);
            min_index = 0;
            min = arr[0];
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] < min) {
                    min = arr[i];
                    min_index = i;
                }
            }
        } else {
            a.pop();
        }
    }

    public int top() {
        return a.peek();
    }

    public int getMin() {
        return min;
    }
}
