package _566重塑矩阵;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution0 solution0 = new Solution0();
        int[][] arr = {{1, 2}, {3, 4}};
        int[][] a = solution0.matrixReshape(arr, 4, 1);
    }
}
