package _1742盒子中小球的最大数量;

import java.util.Arrays;
import java.util.WeakHashMap;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int countBalls(int lowLimit, int highLimit) {
        int max = 0;
        int[] arr = new int[46];
        for (int i = lowLimit; i < highLimit + 1; i++) {
            int j = getBoxNum(i);
            arr[j]++;
            if (arr[j] > max) {
                max = arr[j];
            }
        }
        return max;
    }

    public int getBoxNum(int num) {
        int boxNum = 0;
        for (int i = 4; i >= 0; i--) {
            int firstNum = num / (int) (Math.pow(10, i));
            boxNum += firstNum;
            num -= firstNum * (int) (Math.pow(10, i));
        }
        return boxNum;
    }
}
