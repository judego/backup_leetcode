package _1742盒子中小球的最大数量;

import java.util.HashMap;
import java.util.Map;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int countBalls(int lowLimit, int highLimit) {
        HashMap<Integer, Integer> box = new HashMap<>();
        int result = 0;
        for (int i = lowLimit; i < highLimit + 1; i++) {
            box.put(getBoxNum(i), box.getOrDefault(getBoxNum(i), 0) + 1);
            result = Math.max(result, box.get(getBoxNum(i)));
        }
        return result;
    }

    public int getBoxNum(int num) {
        int result = 0;
        while (num != 0) {
            result += num % 10;
            num /= 10;
        }
        return result;
    }
}
