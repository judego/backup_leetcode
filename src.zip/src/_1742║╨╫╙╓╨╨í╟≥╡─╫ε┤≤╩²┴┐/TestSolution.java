package _1742盒子中小球的最大数量;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution1 solution1 = new Solution1();
        System.out.println(solution1.countBalls(19,28));
    }
}
