package _59滑动窗口最大值;

/**
 * @author wen
 * @version 1.0
 */
public class Test1 {
    public static void main(String[] args) {
        Solution s = new Solution();
        int[] a = {1, 3, -1, -3, 5, 3, 6, 7};
        int[] arr = s.maxSlidingWindow(a, 3);
    }
}
