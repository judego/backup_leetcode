package _1828统计一个圆中点的数目;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int[] countPoints(int[][] points, int[][] queries) {
        int[] res = new int[queries.length];
        for (int i = 0; i < queries.length; i++) {
            int x = queries[i][0], y = queries[i][1], r = queries[i][2], count = 0;
            for (int[] point : points) {
                if ((x - point[0]) * (x - point[0]) + (y - point[1]) * (y - point[1]) <= r * r) count++;
            }
            res[i] = count;
        }
        return res;
    }
}
