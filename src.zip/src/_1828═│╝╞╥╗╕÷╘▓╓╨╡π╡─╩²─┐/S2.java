package _1828统计一个圆中点的数目;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    int[][] points;

    public int[] countPoints(int[][] points, int[][] queries) {
        this.points = points;
        int[] res = new int[queries.length];
        for (int i = 0; i < res.length; i++) {
            res[i] = cal(queries[i][0], queries[i][1], queries[i][2]);
        }
        return res;
    }

    public int cal(int x1, int y1, int r) {
        int count = 0;
        for (int[] point : points) {
            int x2 = point[0], y2 = point[1];
            if ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) <= r * r) count++;
        }
        return count;
    }
}
