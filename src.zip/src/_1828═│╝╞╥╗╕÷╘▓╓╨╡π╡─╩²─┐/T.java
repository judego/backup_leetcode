package _1828统计一个圆中点的数目;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {

    }
}
