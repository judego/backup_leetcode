package _148排序链表;


/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution1 solution0 = new Solution1();
        ListNode d = new ListNode(3);
        ListNode c = new ListNode(1,d);
        ListNode b = new ListNode(2,c);
        ListNode a = new ListNode(4,b);
        ListNode e = solution0.sortList(a);
    }
}
