package _148排序链表;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public ListNode sortList(ListNode head) {
        int count = 0;
        int[] temp = new int[50000];
        for (int i = 0;head != null; i++) {
            temp[i] = head.val;
            count++;
            head = head.next;
        }
        if (count == 0) {
            return head;
        }
        int[] arr = new int[count];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = temp[i];
        }
        Arrays.sort(arr);
        ListNode top = new ListNode();
        ListNode cur =new ListNode(arr[0]);
        top.next = cur;
        for (int i = 1; i < arr.length; i++) {
            cur.next = new ListNode(arr[i]);
            cur = cur.next;
        }
        return top.next;
    }
}
