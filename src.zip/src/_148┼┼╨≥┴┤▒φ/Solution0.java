package _148排序链表;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {

    public ListNode sortList(ListNode head) {
        int length = 0;
        ListNode result = null;
        ListNode pre = head;
        while (pre != null) {
            pre = pre.next;
            length++;
        }
        if (length == 0) {
            return result;
        }
        ListNode top = new ListNode();
        top.next = head;
        for (int i = 0; i < length; i++) {
            pre = top;
            for (int j = 0; j < findMax(top.next); j++) {
                pre = pre.next;
            }
            ListNode cur = pre.next;
            ListNode later = cur.next;
            cur.next = result;
            result = cur;
            pre.next = later;
        }
        return result;
    }

    public int findMax(ListNode head) {
        int max = head.val;
        int count = 0;
        int result = 0;
        while (head != null) {
            if (head.val > max) {
                max = head.val;
                result = count;
            }
            head = head.next;
            count++;
        }
        return result;
    }
}


