package _1753移除石子的最大得分;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.maximumScore(1, 8, 8);
    }
}
