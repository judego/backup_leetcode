package _1753移除石子的最大得分;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int maximumScore(int a, int b, int c) {
        if (a > b + c) return b + c;
        if (b > a + c) return a + c;
        if (c > a + b) return a + b;
        return (a + b + c) / 2;
    }
}
