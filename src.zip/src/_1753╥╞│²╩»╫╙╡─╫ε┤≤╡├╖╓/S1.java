package _1753移除石子的最大得分;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    int res = 0;

    public int maximumScore(int a, int b, int c) {
        if (a < b) {
            return maximumScore(b, a, c);
        }
        if (b < c) {
            return maximumScore(a, c, b);
        }
        res += Math.min(a - c, b - c);
        subtract(a - res, b - res, c);
        return res;
    }

    public void subtract(int a, int b, int c) {
        if (a < b) {
            subtract(b, a, c);
            return;
        }
        if (b < c) {
            subtract(a, c, b);
            return;
        }
        if (b == 0) return;
        a--;
        b--;
        res++;
        subtract(a, b, c);
    }
}
