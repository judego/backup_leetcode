package _2011执行操作后的变量值;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int finalValueAfterOperations(String[] operations) {
        int count = 0;
        for (String operation : operations) if (operation.charAt(1) == '-') count++;
        return operations.length - count * 2;
    }
}
