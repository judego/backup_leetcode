package _2357使数组中所有元素都等于零;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int minimumOperations(int[] nums) {
        int[] record = new int[101];
        for (int num : nums) {
            record[num]++;
        }
        record[0] = 0;
        int res = 0;
        for (int r : record) {
            if (r != 0) res++;
        }
        return res;
    }
}
