package _1124表现良好的最长时间段;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        int res = new S0(){}.longestWPI(new int[]{6,6,9});
    }
}
