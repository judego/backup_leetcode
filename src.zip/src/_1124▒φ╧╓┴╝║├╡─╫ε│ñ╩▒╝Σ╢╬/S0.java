package _1124表现良好的最长时间段;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int longestWPI(int[] hours) {
        int l = 0, r = 0, len = hours.length, flag = 0, res = 0;
        for (int i = 0; i < hours.length; i++) {
            hours[i] = hours[i] > 8 ? 1 : -1;
        }
        while (l < len) {
            while (r < len) {
                flag += hours[r++];
                if (flag + hours[r] <= 0) break;
            }
            res = Math.max(res, r - l);
            flag -= hours[l++];
        }
        return res;
    }
}
