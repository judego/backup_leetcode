package _543二叉树的直径;

import javax.print.DocFlavor;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    int max = 0;

    public int diameterOfBinaryTree(TreeNode root) {

        return Math.max(find(root) - 1, max);
    }

    public int find(TreeNode root) {
        if (root == null) return 0;
        int a = find(root.left), b = find(root.right);
        max = Math.max(max, a + b);
        return Math.max(a, b) + 1;
    }
}
