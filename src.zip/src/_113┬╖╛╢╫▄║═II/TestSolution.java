package _113路径总和II;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        List<List<Integer>> res = new ArrayList<>();
        List<Integer> list = new ArrayList<>();
    }
}
