package _113路径总和II;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode() {
    }

    TreeNode(int val) {
        this.val = val;
    }

    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}

public class S0 {
    List<List<Integer>> res = new ArrayList<>();

    public List<List<Integer>> pathSum(TreeNode root, int targetSum) {
        if (root != null) find(root, new ArrayList<>(), 0, targetSum);
        return res;
    }

    public void find(TreeNode node, List<Integer> list, int count, int targetSum) {
        if (node.left == null && node.right == null) {
            if (count + node.val == targetSum) {
                list.add(node.val);
                res.add(new ArrayList<>(list));
                list.remove(list.size() - 1);
            }
            return;
        }
        list.add(node.val);
        if (node.left != null)
            find(node.left, list, count + node.val, targetSum);
        if (node.right != null)
            find(node.right, list, count + node.val, targetSum);
        list.remove(list.size() - 1);
    }
}
