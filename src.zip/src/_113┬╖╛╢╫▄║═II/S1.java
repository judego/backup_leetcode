package _113路径总和II;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    List<List<Integer>> res = new ArrayList<>();

    public List<List<Integer>> pathSum(TreeNode root, int targetSum) {
        if (root != null) find(root, new ArrayList<>(), 0, targetSum);
        return res;
    }

    public void find(TreeNode node, List<Integer> list, int count, int targetSum) {
        if (node == null) return;
        list.add(node.val);
        if (node.left == null && node.right == null && targetSum == count + node.val) {
            res.add(new ArrayList<>(list));
            list.remove(list.size() - 1);
            return;
        }
        find(node.left, list, count + node.val, targetSum);
        find(node.right, list, count + node.val, targetSum);
        list.remove(list.size() - 1);
    }
}
