package _1758生成交替二进制字符串的最少操作数;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int minOperations(String s) {
        int count1 = s.length();
        int count2 = s.length();
        for (int i = 0; i < s.length(); i++) {
            if (i % 2 == 0 && s.charAt(i) == '0') {
                count1--;
            }
            if (i % 2 == 1 && s.charAt(i) == '1') {
                count1--;
            }
        }
        for (int i = 0; i < s.length(); i++) {
            if (i % 2 == 1 && s.charAt(i) == '0') {
                count2--;
            }
            if (i % 2 == 0 && s.charAt(i) == '1') {
                count2--;
            }
        }
        return count1 < count2 ? count1 : count2;
    }
}
