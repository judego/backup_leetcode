package _1758生成交替二进制字符串的最少操作数;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int minOperations(String s) {
        int result = 0;
        for (int i = 0; i < s.length(); i++) {
            if ((int) s.charAt(i) == 48 + i % 2) {
                result++;
            }
        }
        return Math.min(result, s.length() - result);
    }
}
