package _1758生成交替二进制字符串的最少操作数;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        String a = "0100";
        Solution1 solution0 = new Solution1();
        int b = solution0.minOperations(a);
        System.out.println((int)'0');
    }
}
