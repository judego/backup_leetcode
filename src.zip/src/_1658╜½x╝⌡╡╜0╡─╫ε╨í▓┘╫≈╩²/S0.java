package _1658将x减到0的最小操作数;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int minOperations(int[] nums, int x) {
        int sum = -x, len = -1, n = nums.length;
        for (int num : nums) sum += num;
        if (sum < 0) return -1;
        for (int r = 0, l = 0; r < n; r++) {
            sum -= nums[r];
            while (sum < 0) sum += nums[l++];
            if (sum == 0) len = Math.max(len, r - l + 1);
        }
        return len < 0 ? -1 : n - len;
    }
}
