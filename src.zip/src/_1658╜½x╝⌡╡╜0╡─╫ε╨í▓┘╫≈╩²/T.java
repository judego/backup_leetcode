package _1658将x减到0的最小操作数;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] arr = {3,2,20,1,1,3};
        int b = s0.minOperations(arr, 10);
    }
}
