package _1139最大的以1为边界的正方形;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {

    }
}
