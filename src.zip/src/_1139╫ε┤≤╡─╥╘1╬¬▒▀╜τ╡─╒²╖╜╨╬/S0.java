package _1139最大的以1为边界的正方形;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int largest1BorderedSquare(int[][] grid) {
        int res = 0, r = grid.length, c = grid[0].length;
        int[][][] dp = new int[r + 1][c + 1][2];
        for (int i = 1; i <= r; i++) {
            for (int j = 1; j <= c; j++) {
                if (grid[i - 1][j - 1] == 1) {
                    dp[i][j][0] = dp[i][j - 1][0] + 1;
                    dp[i][j][1] = dp[i - 1][j][1] + 1;
                }
            }
        }
        for (int i = 1; i <= r; i++) {
            for (int j = 1; j <= c; j++) {
                for (int side = Math.min(dp[i][j][0], dp[i][j][1]); side > res; side--) {
                    if (dp[i][j - side + 1][1] >= side && dp[i - side + 1][j][0] >= side) res = side;
                }
            }
        }
        return res * res;
    }
}
