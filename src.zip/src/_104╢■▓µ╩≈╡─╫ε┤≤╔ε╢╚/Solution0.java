package _104二叉树的最大深度;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int maxDepth(TreeNode root) {
        Queue<TreeNode> queue = new LinkedList<>();
        if (root != null) queue.add(root);
        int max = 0;
        while (!queue.isEmpty()) {
            int length = queue.size();
            for (int i = 0; i < length; i++) {
                TreeNode tempNode = queue.poll();
                if (tempNode.left != null) queue.add(tempNode.left);
                if (tempNode.right != null) queue.add(tempNode.right);
            }
            max++;
        }
        return max;
    }
}
