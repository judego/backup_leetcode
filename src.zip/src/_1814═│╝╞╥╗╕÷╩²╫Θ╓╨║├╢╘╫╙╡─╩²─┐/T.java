package _1814统计一个数组中好对子的数目;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] arr = {4247,11,1,97};
        int a = s0.countNicePairs(arr);
    }
}
