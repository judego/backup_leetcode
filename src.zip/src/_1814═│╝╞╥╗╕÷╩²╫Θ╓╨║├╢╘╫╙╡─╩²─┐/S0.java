package _1814统计一个数组中好对子的数目;

import java.util.HashMap;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int countNicePairs(int[] nums) {
        final int mod = 1000000007;
        int res = 0;
        HashMap<Integer, Integer> mp = new HashMap<>();
        for (int num : nums) {
            int temp = num, reverse = 0;
            while (temp != 0) {
                reverse = reverse * 10 + temp % 10;
                temp /= 10;
            }
            int a = mp.getOrDefault(num - reverse, 0);
            res = (res + a) % mod;
            mp.put(num - reverse, a + 1);
        }
        return res;
    }
}
