package _1814统计一个数组中好对子的数目;

import java.util.HashMap;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int countNicePairs(int[] nums) {
        int[] rev = new int[nums.length];
        int res = 0;
        for (int i = 0; i < nums.length; i++) {
            int temp = nums[i];
            while (temp != 0) {
                rev[i] = rev[i] * 10 + temp % 10;
                temp /= 10;
            }
            rev[i] -= nums[i];
        }
        HashMap<Integer, Integer> mp = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            mp.put(rev[i], mp.getOrDefault(rev[i], 0) + 1);
        }
        for (int value : mp.values()) {
            res += ((long) value * (value - 1) / 2) % 1000000007;
        }
        return res % 1000000007;
    }
}
