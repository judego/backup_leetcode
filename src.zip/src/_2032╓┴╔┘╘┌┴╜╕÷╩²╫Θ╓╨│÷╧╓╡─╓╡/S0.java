package _2032至少在两个数组中出现的值;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public List<Integer> twoOutOfThree(int[] nums1, int[] nums2, int[] nums3) {
        int[] t1 = new int[100], t2 = new int[100], t3 = new int[100];
        List<Integer> res = new ArrayList<>();
        for (int i : nums1) t1[i - 1] = 1;
        for (int i : nums2) t2[i - 1] = 1;
        for (int i : nums3) t3[i - 1] = 1;
        for (int i = 0; i < 100; i++) if (t1[i] + t2[i] + t3[i] > 1) res.add(i + 1);
        return res;
    }
}
