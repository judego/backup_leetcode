package _4寻找两个正序数组的中位数;

import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public double findMedianSortedArrays(int[] nums1, int[] nums2) {
        int len1 = nums1.length, len2 = nums2.length, p1 = len1 / 2, p2 = len2 / 2, target = (len1 + len2 - 1) / 2;
        if (len2 > len1) return findMedianSortedArrays(nums2, nums1);
        return 0;
    }
}
