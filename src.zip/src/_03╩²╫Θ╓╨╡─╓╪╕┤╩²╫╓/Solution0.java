package _03数组中的重复数字;

import java.util.HashMap;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int findRepeatNumber(int[] nums) {
        int result = 0;
        HashMap<Integer, Integer> box = new HashMap<>();
        for (int num : nums) {
            box.put(num, box.getOrDefault(num, 0) + 1);
            if (box.get(num) != null && box.get(num) == 2) {
                result = num;
                break;
            }
        }
        return result;
    }
}
