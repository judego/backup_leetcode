package _03数组中的重复数字;

import java.util.HashMap;
import java.util.HashSet;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int findRepeatNumber(int[] nums) {
        HashSet<Integer> box = new HashSet<>();
        for (int num : nums) {
            if (box.contains(num)) {
                return num;
            }
            box.add(num);
        }
        return -1;
    }
}
