package _03数组中的重复数字;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        int[] arr = {1, 2, 2, 3, 4, 56, 7};
        Solution0 solution0 = new Solution0();
        System.out.println(solution0.findRepeatNumber(arr));
    }
}
