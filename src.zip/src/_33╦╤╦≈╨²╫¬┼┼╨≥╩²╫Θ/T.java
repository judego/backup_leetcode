package _33搜索旋转排序数组;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] arr = {4,5,6,7,0,1,2};
        int a = s0.search(arr, 3);
    }
}
