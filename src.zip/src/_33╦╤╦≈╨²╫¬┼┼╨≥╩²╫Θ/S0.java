package _33搜索旋转排序数组;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int search(int[] nums, int target) {
        int n = nums.length;
        int minIndex = find(nums, nums[n - 1], 0, n - 1, false);
        int a = find(nums, target, 0, minIndex - 1, true);
        int b = find(nums, target, minIndex, n - 1, true);
        if (nums[a] == target) return a;
        if (b < n && nums[b] == target) return b;
        return -1;
    }

    public int find(int[] nums, int target, int l, int r, boolean flag) {
        while (l <= r) {
            int m = (l + r) / 2;
            if ((flag && nums[m] < target) || (!flag && nums[m] > target)) l = m + 1;
            else r = m - 1;
        }
        return l;
    }
}
