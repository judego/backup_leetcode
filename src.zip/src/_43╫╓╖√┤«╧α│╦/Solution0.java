package _43字符串相乘;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public String multiply(String num1, String num2) {
        if (num1.length() > num2.length()) return multiply(num2, num1);
        byte[] res = new byte[num1.length() + num2.length() + 1];
        byte[] s1 = new byte[num1.length()];
        byte[] s2 = new byte[num2.length()];
        for (int i = 0; i < num1.length(); i++) {
            s1[i] = (byte) (num1.charAt(i) - 48);
        }
        for (int i = 0; i < num2.length(); i++) {
            s2[i] = (byte) (num2.charAt(i) - 48);
        }
        int p1 = s1.length - 1, count = 0;
        while (p1 >= 0) {
            int p2 = s2.length - 1, p_res = res.length - 1 - count;
            while (p2 >= 0) {
                res[p_res] += (byte) (s1[p1] * s2[p2]);
                res[p_res - 1] += res[p_res] / 10;
                res[p_res] %= 10;
                p_res--;
                p2--;
            }
            count++;
            p1--;
        }
        int p = 0;
        String d = "";
        while (p < res.length) {
            if (p != res.length - 1 && res[p] == 0) p++;
            else break;
        }
        for (; p < res.length; p++) {
            d += res[p];
        }
        return d;
    }
}
