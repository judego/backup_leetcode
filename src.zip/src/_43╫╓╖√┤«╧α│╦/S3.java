package _43字符串相乘;

/**
 * @author wen
 * @version 1.0
 */
public class S3 {
    public String multiply(String num1, String num2) {
        if (num1.equals("0") || num2.equals("0")) return "0";
        int[] res = new int[num1.length() + num2.length()];
        for (int p1 = (num1.length() - 1), count = 0; p1 >= 0; count++, p1--) {
            for (int p2 = (num2.length() - 1), p_res = (res.length - 1 - count);
                 p2 >= 0; p2--, p_res--) {
                res[p_res] += (num1.charAt(p1) - '0') * (num2.charAt(p2) - '0');
            }
        }
        StringBuffer d = new StringBuffer();
        for (int i = res.length - 1; i > 0; i--) {
            res[i - 1] += res[i] / 10;
            res[i] %= 10;
            d.insert(0, res[i]);
        }
        if (res[0] != 0) d.insert(0, res[0]);
        return d.toString();
    }
}
