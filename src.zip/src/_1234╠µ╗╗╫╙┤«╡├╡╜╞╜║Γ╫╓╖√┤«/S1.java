package _1234替换子串得到平衡字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    int quarter;
    int[] ch = new int[19];

    public int balancedString(String s) {
        int len = s.length();
        quarter = len / 4;
        char[] str = s.toCharArray();
        for (char c : str) ch[c - 69]++;
        if (check()) return 0;
        int l = 0, r = l, res = len;
        while (l < len) {
            while (r < len && !check()) ch[str[r++] - 69]--;
            if (!check()) break;
            res = Math.min(res, r - l);
            while (r - l >= res) ch[str[l++] - 69]++;
        }
        return res;
    }

    public boolean check() {
        return ch[0] <= quarter && ch[12] <= quarter && ch[13] <= quarter && ch[18] <= quarter;
    }
}
