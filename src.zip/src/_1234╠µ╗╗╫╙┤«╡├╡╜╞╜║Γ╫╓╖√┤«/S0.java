package _1234替换子串得到平衡字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    int a1 = 0, a2 = a1, a3 = a2, a4 = a3, quarter;

    public int balancedString(String s) {
        int len = s.length();
        quarter = len / 4;
        char[] str = s.toCharArray();
        for (char c : str) addNum(c);
        if (check()) return 0;
        int l = 0, r = l, res = len;
        while (l < len) {
            while (r < len && !check()) subtractNum(str[r++]);
            if (!check()) break;
            res = Math.min(res, r - l);
            while (r - l >= res) addNum(str[l++]);
        }
        return res;
    }

    public boolean check() {
        return a1 <= quarter && a2 <= quarter && a3 <= quarter && a4 <= quarter;
    }

    public void addNum(char c) {
        if (c == 81) a1++;
        else if (c == 87) a2++;
        else if (c == 69) a3++;
        else if (c == 82) a4++;
    }

    public void subtractNum(char c) {
        if (c == 81) a1--;
        else if (c == 87) a2--;
        else if (c == 69) a3--;
        else if (c == 82) a4--;
    }
}
