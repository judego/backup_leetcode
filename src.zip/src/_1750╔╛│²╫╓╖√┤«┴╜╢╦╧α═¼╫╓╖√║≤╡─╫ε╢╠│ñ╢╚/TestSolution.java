package _1750删除字符串两端相同字符后的最短长度;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.minimumLength("bbbbbbbbbbbbbbbbbbb");
    }
}
