package _1750删除字符串两端相同字符后的最短长度;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int minimumLength(String s) {
        char[] arr = s.toCharArray();
        int n = arr.length, l = 0, r = n - 1;
        while (l < r) {
            if (arr[l] != arr[r]) break;
            while (l < n - 1 && arr[l] == arr[++l]) ;
            while (r > 0 && arr[r] == arr[--r]) ;
        }
        return Math.max(r - l + 1, 0);
    }
}
