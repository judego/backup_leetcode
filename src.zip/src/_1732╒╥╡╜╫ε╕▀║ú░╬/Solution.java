package _1732找到最高海拔;

/**
 * @author wen
 * @version 1.0
 */
public class Solution {
    public int largestAltitude(int[] gain) {
        int record = 0;
        int cur = 0;
        for (int i : gain) {
            cur += i;
            if (i > 0 && cur >= record) {
                record = cur;
            }
        }
        return record;
    }
}
//        for (int i = 0; i < gain.length; i++) {
//            cur += gain[i];
//            if (gain[i] > 0 && cur >= record) {
//                record = cur;
//            }
//        }


