package _1807替换字符串中的括号内容;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S1 s1 = new S1();
        List<List<String>> knowledge = new ArrayList<>();
        List<String> temp = new ArrayList<>();
        temp.add("name");
        temp.add("bob");
        knowledge.add(temp);
        temp = new ArrayList<>();
        temp.add("age");
        temp.add("two");
        knowledge.add(temp);
        String res = s1.evaluate("(name)is(age)yearsold", knowledge);
    }
}
