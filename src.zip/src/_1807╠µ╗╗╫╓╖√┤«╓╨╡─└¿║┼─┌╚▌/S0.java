package _1807替换字符串中的括号内容;

import java.util.HashMap;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String evaluate(String s, List<List<String>> knowledge) {
        HashMap<String, String> mp = new HashMap<>(knowledge.size());
        StringBuilder sb = new StringBuilder(), temp = new StringBuilder();
        char[] sc = s.toCharArray();
        boolean flag = false;
        for (List<String> list : knowledge) {
            mp.put(list.get(0), list.get(1));
        }
        for (char c : sc) {
            if (c == '(') {
                flag = true;
                temp = new StringBuilder();
            } else if (c == ')') {
                String inBracket = mp.get(temp.toString());
                sb.append(inBracket == null ? "?" : inBracket);
                flag = false;
            } else if (flag) {
                temp.append(c);
            } else sb.append(c);
        }
        return sb.toString();
    }
}
