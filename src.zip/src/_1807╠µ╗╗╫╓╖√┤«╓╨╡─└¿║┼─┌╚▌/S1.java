package _1807替换字符串中的括号内容;

import java.util.HashMap;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public String evaluate(String s, List<List<String>> knowledge) {
        HashMap<String, String> mp = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        for (List<String> list : knowledge) {
            mp.put(list.get(0), list.get(1));
        }
        String[] sc = s.split("\\)");
        for (String s1 : sc) {
            String[] temp = s1.split("\\(");
            sb.append(temp[0]);
            if (temp.length == 2) sb.append(mp.getOrDefault(temp[1], "?"));
        }
        return sb.toString();
    }
}
