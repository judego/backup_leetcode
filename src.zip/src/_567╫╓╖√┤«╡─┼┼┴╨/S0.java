package _567字符串的排列;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public boolean checkInclusion(String s1, String s2) {
        int[] arr = new int[26];
        char[] c1 = s1.toCharArray();
        char[] c2 = s2.toCharArray();
        for (char c : c1) {
            arr[c - 'a']--;
        }
        int left = 0, n = c1.length;
        for (int i = 0; i < c2.length; i++) {
            arr[c2[i] - 'a']++;
            while (arr[c2[i] - 'a'] > 0) {
                arr[c2[left] - 'a']--;
                left++;
            }
            if (i - left + 1 == n) return true;
        }
        return false;
    }
}
