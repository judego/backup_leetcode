package _203移除链表元素;

/**
 * @author wen
 * @version 1.0
 */
class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}

public class Solution0 {
    public ListNode removeElements(ListNode head, int val) {
        ListNode res = new ListNode();
        ListNode cur = res;
        while (head != null) {
            if (head.val != val) {
                ListNode temp = head.next;
                cur.next = head;
                head.next = null;
                head = temp;
                cur = cur.next;
            } else head = head.next;
        }
        return res.next;
    }
}
