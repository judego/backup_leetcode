package _203移除链表元素;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public ListNode removeElements(ListNode head, int val) {
        if (head == null) return head;
        head.next = removeElements(head.next, val);
        return head.val == val ? head.next : head;
    }
}
