package _130被围绕的区域;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    boolean[][] record;
    char[][] board;
    int row, column;

    public void solve(char[][] board) {
        row = board.length;
        column = board[0].length;
        record = new boolean[row][column];
        this.board = board;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                if (i == 0 || i == row - 1 || j == 0 || j == column - 1) fill(i, j);
            }
        }
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                board[i][j] = record[i][j] ? 'O' : 'X';
            }
        }
    }

    public void fill(int x, int y) {
        if (x < 0 || x >= row || y < 0 || y >= column || board[x][y] == 'X') return;
        else {
            board[x][y] = 'X';
            record[x][y] = true;
        }
        fill(x + 1, y);
        fill(x - 1, y);
        fill(x, y + 1);
        fill(x, y - 1);
    }
}
