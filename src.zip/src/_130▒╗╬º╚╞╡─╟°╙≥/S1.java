package _130被围绕的区域;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    boolean[][] record;
    char[][] board;
    int row, column;

    public void solve(char[][] board) {
        row = board.length;
        column = board[0].length;
        record = new boolean[row][column];
        this.board = board;
        for (int i = 0; i < column; i++) {
            fill(0, i);
            fill(row - 1, i);
        }
        for (int i = 1; i < row - 1; i++) {
            fill(i, 0);
            fill(i, column - 1);
        }
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                board[i][j] = record[i][j] ? 'O' : 'X';
            }
        }
    }

    public void fill(int x, int y) {
        if (x < 0 || x >= row || y < 0 || y >= column || board[x][y] == 'X') return;
        else {
            board[x][y] = 'X';
            record[x][y] = true;
        }
        fill(x + 1, y);
        fill(x - 1, y);
        fill(x, y + 1);
        fill(x, y - 1);
    }
}
