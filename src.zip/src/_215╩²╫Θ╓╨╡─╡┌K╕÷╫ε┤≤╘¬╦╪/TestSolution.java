package _215数组中的第K个最大元素;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] arr = {3, 2, 1, 5, 6, 4};
        int a = s0.findKthLargest(arr,2);
    }
}
