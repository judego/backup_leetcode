package _215数组中的第K个最大元素;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    int[] num;

    public int quickSort(int l, int r, int k) {
        if (l == r) return num[k];
        int i = l - 1, j = r + 1, x = num[(l + r) / 2];
        while (i < j) {
            while (num[++i] < x) ;
            while (num[--j] > x) ;
            if (i < j) swap(i, j);
        }
        if (k <= j) return quickSort(l, j, k);
        else return quickSort(j + 1, r, k);
    }

    public void swap(int a, int b) {
        int temp = num[a];
        num[a] = num[b];
        num[b] = temp;
    }

    public int findKthLargest(int[] nums, int k) {
        this.num = nums;
        return quickSort(0, num.length - 1, num.length - k);
    }
}
