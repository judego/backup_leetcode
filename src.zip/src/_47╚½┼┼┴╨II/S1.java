package _47全排列II;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    boolean[] used;
    int[] temp;
    List<List<Integer>> res = new ArrayList<>();

    public List<List<Integer>> permuteUnique(int[] nums) {
        used = new boolean[nums.length];
        temp = new int[nums.length];
        Arrays.sort(nums);
        arrange(nums, 0);
        return res;
    }

    public void arrange(int[] nums, int p) {
        if (p == nums.length) {
            List<Integer> list = new ArrayList<>();
            for (int i : temp) {
                list.add(i);
            }
            res.add(list);
            return;
        }
        for (int i = 0; i < nums.length; i++) {
            if (used[i] || (i > 0 && nums[i] == nums[i - 1] && !used[i - 1])) continue;
            used[i] = true;
            temp[p] = nums[i];
            arrange(nums, p + 1);
            used[i] = false;
        }
    }
}
