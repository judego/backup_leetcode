package _47全排列II;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] arr = {1,1,2};
        List<List<Integer>> res = s0.permuteUnique(arr);
    }
}
