package _1827最少操作使数组递增;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
}
