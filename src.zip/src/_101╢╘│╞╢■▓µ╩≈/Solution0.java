package _101对称二叉树;

import java.util.LinkedList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 * 有问题的答案
 */
public class Solution0 {
    public boolean isSymmetric(TreeNode root) {
        List<Integer> list1 = new LinkedList<>();
        List<Integer> list2 = new LinkedList<>();
        find(list1, root.left);
        find(list2, root.right);
        if (list1.size() != list2.size()) return false;
        Integer[] arr1 = list1.toArray(new Integer[list1.size()]);
        Integer[] arr2 = list2.toArray(new Integer[list1.size()]);
        for (int i = 0; i < arr1.length; i++) {
            if (!arr1[i].equals(arr2[i])) return false;
        }
        return true;
    }

    public void find(List<Integer> list, TreeNode root) {
        if (root == null) return;
        find(list, root.left);
        list.add(root.val);
        find(list, root.right);
    }
}
