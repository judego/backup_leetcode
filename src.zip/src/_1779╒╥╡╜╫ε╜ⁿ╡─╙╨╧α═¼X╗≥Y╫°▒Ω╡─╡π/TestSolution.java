package _1779找到最近的有相同X或Y坐标的点;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {

    }
}
