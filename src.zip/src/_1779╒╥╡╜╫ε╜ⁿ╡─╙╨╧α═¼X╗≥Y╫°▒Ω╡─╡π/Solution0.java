package _1779找到最近的有相同X或Y坐标的点;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int nearestValidPoint(int x, int y, int[][] points) {
        int[] arr = new int[points.length];
        int minLength = 2147483647;
        int min = -1;
        for (int i = 0; i < points.length; i++) {
            if (points[i][0] == x||points[i][1] == y) {
                arr[i] = Math.abs(points[i][0] - x) + Math.abs(points[i][1] - y);
            }else arr[i] = -1;
        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != -1 && arr[i] < minLength) {
                minLength = arr[i];
                min = i;
            }
        }
        return min;
    }
}
