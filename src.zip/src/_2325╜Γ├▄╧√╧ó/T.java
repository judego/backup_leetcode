package _2325解密消息;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        String res = new S0() {
        }.decodeMessage("the quick brown fox jumps over the lazy dog",
                "vkbs bs t suepuv");
    }
}
