package _2325解密消息;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String decodeMessage(String key, String message) {
        char[] contrast = new char[26];
        int used = 0;
        char cur = 'a';
        for (char c : key.toCharArray()) {
            if (c == ' ') continue;
            if (((1 << (c - 'a')) & used) == 0) {
                used += (1 << (c - 'a'));
                contrast[c - 'a'] = cur++;
            }
            if (cur > 'z') break;
        }
        char[] s = message.toCharArray();
        for (int i = 0; i < s.length; i++) {
            if (s[i] != ' ') s[i] = contrast[s[i] - 'a'];
        }
        return new String(s);
    }}
