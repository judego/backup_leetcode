package _48旋转图像;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public void rotate(int[][] matrix) {
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < i; j++) {
                change(matrix, i, j, j, i);
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= n / 2 - 1; j++) {
                change(matrix, i, j, i, n - j - 1);
            }
        }
    }

    public void change(int[][] matrix, int a, int b, int c, int d) {
        matrix[a][b] ^= matrix[c][d];
        matrix[c][d] ^= matrix[a][b];
        matrix[a][b] ^= matrix[c][d];
    }
}
