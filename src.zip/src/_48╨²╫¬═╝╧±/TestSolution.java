package _48旋转图像;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[][] arr = {{1,2,3},{4,5,6},{7,8,9}};
        s0.rotate(arr);
    }
}
