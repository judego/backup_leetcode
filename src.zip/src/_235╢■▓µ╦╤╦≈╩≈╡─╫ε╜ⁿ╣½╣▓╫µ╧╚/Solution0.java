package _235二叉搜索树的最近公共祖先;


/**
 * @author wen
 * @version 1.0
 */
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int x) {
        val = x;
    }
}

public class Solution0 {
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        int a = Math.min(q.val, p.val), b = Math.max(q.val, p.val);
        while (root.val < a || root.val > b) {
            if (root.val > b) root = root.left;
            else root = root.right;
        }
        return root;
    }
}
