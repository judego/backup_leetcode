package _1817查找用户活跃分钟数;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int[] findingUsersActiveMinutes(int[][] logs, int k) {
        Arrays.sort(logs, (i, j) -> i[0] == j[0] ? i[1] - j[1] : i[0] - j[0]);
        int[] res = new int[k];
        int id = logs[0][0], time = 0, count = 0;
        for (int[] log : logs) {
            if (log[0] != id) {
                if (count <= k) res[count - 1]++;
                id = log[0];
                time = log[1];
                count = 1;
            } else if (log[1] > time) {
                count++;
                time = log[1];
            }
        }
        if (count <= k) res[count - 1]++;
        return res;
    }
}
