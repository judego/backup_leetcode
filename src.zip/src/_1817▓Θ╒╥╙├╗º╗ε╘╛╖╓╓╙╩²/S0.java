package _1817查找用户活跃分钟数;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int[] findingUsersActiveMinutes(int[][] logs, int k) {
        HashMap<Integer, Set<Integer>> mp = new HashMap<>();
        for (int[] log : logs) {
            mp.putIfAbsent(log[0], new HashSet<>());
            mp.get(log[0]).add(log[1]);
        }
        int[] res = new int[k];
        for (Set<Integer> minutes : mp.values()) {
            res[minutes.size() - 1]++;
        }
        return res;
    }
}
