package _141环形链表;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public boolean hasCycle(ListNode head) {
        for (int i = 200000; head != null && head.next != null; i++) {
            head.val = i;
            head = head.next;
            if (head.val >= 200000) {
                return true;
            }
        }
        return false;
    }
}


class ListNode {
    int val;
    ListNode next;

    ListNode(int x) {
        val = x;
        next = null;
    }
}
