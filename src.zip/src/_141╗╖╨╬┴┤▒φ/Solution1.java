package _141环形链表;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public boolean hasCycle(ListNode head) {
        ListNode a = head, b = head;
        while (b != null && b.next != null) {
            a = a.next;
            b = b.next.next;
            if (a == b) return true;
        }
        return false;
    }
}
