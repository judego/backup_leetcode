package _39组合总和;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] arr = {2,3,6,7};
        List<List<Integer>> res = s0.combinationSum(arr, 7);
    }
}
