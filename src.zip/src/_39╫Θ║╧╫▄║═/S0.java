package _39组合总和;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    List<List<Integer>> res;
    int[] can;
    int target;
    boolean flag = true;

    public List<List<Integer>> combinationSum(int[] candidates, int target) {
        Arrays.sort(candidates);
        this.can = candidates;
        this.target = target;
        res = new ArrayList<>();
        dfs(0, 0, new ArrayList<>());
        return res;
    }

    public void dfs(int start, int sum, List<Integer> list) {
        if (sum > target) {
            flag = false;
            return;
        }
        if (sum == target) {
            flag = false;
            res.add(new ArrayList<>(list));
            return;
        }
        for (int i = start; i < can.length && flag; i++) {
            list.add(can[i]);
            dfs(i, sum + can[i], list);
            list.remove(list.size() - 1);
        }
        flag = true;
    }
}
