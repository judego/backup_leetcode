package _53在排序数组中查找数字I;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        int[] arr = {5, 7, 7, 8, 8, 10};
        Solution0 solution0 = new Solution0();
        System.out.println(solution0.search(arr, 8));
    }
}
