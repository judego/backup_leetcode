package _53在排序数组中查找数字I;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int search(int[] nums, int target) {
        return helper(nums, target) - helper(nums, target - 1);
    }

    public int helper(int[] arr, int target) {
        int i = 0;
        int j = arr.length - 1;
        while (i <= j) {
            int m = (i + j) / 2;
            if (arr[m] <= target) {
                i = m + 1;
            } else j = m - 1;
        }
        return i;
    }
}
