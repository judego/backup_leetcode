package _24两两交换链表中的节点;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        ListNode d = new ListNode(4);
        ListNode c = new ListNode(3, d);
        ListNode b = new ListNode(2, c);
        ListNode a = new ListNode(1, b);
        Solution0 solution0 = new Solution0();
        ListNode result = solution0.swapPairs(a);
    }
}
