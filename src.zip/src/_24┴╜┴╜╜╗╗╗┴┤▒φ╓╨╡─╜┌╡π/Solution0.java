package _24两两交换链表中的节点;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public ListNode swapPairs(ListNode head) {
        if (head == null || head.next == null) return head;
        ListNode top1 = new ListNode(), top2 = new ListNode(),pre1 = top1;
        ListNode cur1 = head, cur2;
        top1.next = head;
        while (cur1 != null){
            if (cur1.next == null) break;
            cur2 = cur1.next;
            pre1.next = null;
            top2.next = cur1;
            cur1.next =null;
            pre1.next = cur2;
            if (cur2.next == null) {
                top2.next = null;
                cur2.next = cur1;
            }else {
                ListNode lat1 = cur2.next;
                cur2.next = null;
                cur1.next = lat1;
                top2.next = null;
                cur2.next = cur1;
            }
            pre1 = cur1;
            cur1 = cur1.next;
        }
        return top1.next;
    }
}

class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}
