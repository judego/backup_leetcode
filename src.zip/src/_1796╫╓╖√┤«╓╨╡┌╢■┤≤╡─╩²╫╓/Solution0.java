package _1796字符串中第二大的数字;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int secondHighest(String s) {
        char[] arr = new char[s.length()];
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) <= '9' && s.charAt(i) >= '0') {
                arr[i] = s.charAt(i);
            }
        }
        Arrays.sort(arr);
        for (int i = arr.length - 2; i >= 0; i--) {
            if (arr[i] != arr[arr.length - 1] && arr[i] >= '0') {
                return arr[i] - '0';
            }
        }
        return -1;
    }
}
