package _1796字符串中第二大的数字;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int secondHighest(String s) {
        int last = '0' - 1, second = last;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) >= '0' && s.charAt(i) <= '9' && s.charAt(i) != last && s.charAt(i) != second) {
                if (s.charAt(i) > last) {
                    second = last;
                    last = s.charAt(i);
                    continue;
                }
                if (s.charAt(i) > second) {
                    second = s.charAt(i);
                }
            }
        }
        return second - '0';
    }
}
