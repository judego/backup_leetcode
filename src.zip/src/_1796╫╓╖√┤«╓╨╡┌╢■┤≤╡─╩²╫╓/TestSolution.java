package _1796字符串中第二大的数字;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        String s = "sjhtz8344";
        Solution1 solution0 = new Solution1();
        int a = solution0.secondHighest(s);
    }
}
