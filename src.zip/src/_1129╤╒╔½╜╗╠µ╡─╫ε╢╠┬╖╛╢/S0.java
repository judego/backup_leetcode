package _1129颜色交替的最短路径;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
}
