package _160相交链表;

import java.util.HashSet;

/**
 * @author wen
 * @version 1.0
 */

class ListNode {
    int val;
    ListNode next;

    ListNode(int x) {
        val = x;
        next = null;
    }
}


public class Solution0 {
    public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        HashSet<ListNode> hm = new HashSet<>();
        while (headA != null) {
            hm.add(headA);
            headA = headA.next;
        }
        while (headB != null) {
            if (hm.contains(headB)) return headB;
            headB = headB.next;
        }
        return null;
    }
}
