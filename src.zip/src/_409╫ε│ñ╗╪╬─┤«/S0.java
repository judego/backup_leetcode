package _409最长回文串;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int longestPalindrome(String s) {
        int res = 0;
        boolean flag = false;
        int[] count = new int[52];
        for (char c : s.toCharArray()) {
            if (c >= 'a') count[c - 'a']++;
            else count[c - 'A' + 26]++;
        }
        for (int i : count) {
            if (i % 2 == 0) res += i;
            else {
                flag = true;
                res += i / 2 * 2;
            }
        }
        return flag ? res + 1 : res;
    }
}
