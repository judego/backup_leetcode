package _409最长回文串;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int res = s0.longestPalindrome("abccccdd");
    }
}
