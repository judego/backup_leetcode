package _190颠倒二进制位;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int reverseBits(int n) {
        return Integer.reverse(n);
    }
}
