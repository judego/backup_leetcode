package _190颠倒二进制位;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int reverseBits(int n) {
        int res = 0;
        for (int i = 0; i < 32; i++) {
            res += (((n >> i) & 1) << (31 - i));
        }
        return res;
    }
}
