package _190颠倒二进制位;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.reverseBits(0b00000010100101000001111010011100);
        System.out.println(Integer.toBinaryString(0xcccccccc));
    }
}
