package _557反转字符串中的单词III;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public String reverseWords(String s) {
        int n = s.length();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            if (s.charAt(i) == ' ') {
                sb.append(' ');
                continue;
            }
            int j = i;
            while (j < n - 1 && s.charAt(j + 1) != ' ') {
                j++;
            }
            int temp = j;
            while (j >= i) {
                sb.append(s.charAt(j));
                j--;
            }
            i = temp;
        }
        return sb.toString();
    }
}
