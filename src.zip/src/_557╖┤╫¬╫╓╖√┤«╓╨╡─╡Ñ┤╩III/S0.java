package _557反转字符串中的单词III;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String reverseWords(String s) {
        String[] arr = s.split(" ");
        StringBuilder sb = new StringBuilder();
        char[] temp1 = arr[0].toCharArray();
        for (int i = temp1.length - 1; i >= 0; i--) {
            sb.append(temp1[i]);
        }
        for (int i = 1; i < arr.length; i++) {
            sb.append(' ');
            char[] temp2 = arr[i].toCharArray();
            for (int j = temp2.length - 1; j >= 0; j--) {
                sb.append(temp2[j]);
            }
        }
        return sb.toString();
    }
}
