package _557反转字符串中的单词III;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S1 s1 = new S1();
        String s = s1.reverseWords("Let's take LeetCode contest");
    }
}
