package _144二叉树的前序遍历;

import sun.reflect.generics.tree.Tree;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */

class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode() {
    }

    TreeNode(int val) {
        this.val = val;
    }

    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}

public class Solution0 {
    public List<Integer> preorderTraversal(TreeNode root) {
        List<Integer> res = new ArrayList<>();
        find(root, res);
        return res;
    }
    public void find(TreeNode root, List<Integer> list) {
        if (root == null) return;
        list.add(root.val);
        find(root.left, list);
        find(root.right, list);
    }
}
