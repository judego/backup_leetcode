package _189轮转数组;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S1 s0 = new S1();
        int[] arr = {1,2};
        s0.rotate(arr,3);
    }
}
