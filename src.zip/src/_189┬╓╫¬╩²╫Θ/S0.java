package _189轮转数组;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public void rotate(int[] nums, int k) {
        int index = k % nums.length, temp = 0;
        if (index == temp) return;
        for (int i = 0; i < nums.length - 1 - temp; i++) {
            nums[index] = nums[index] ^ nums[temp];
            nums[temp] = nums[index] ^ nums[temp];
            nums[index] = nums[index] ^ nums[temp];
            index = (index + k) % nums.length;
            if (index == temp) {
                temp++;
                index = (temp + k) % nums.length;
            }
        }
    }
}
