package _189轮转数组;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public void rotate(int[] nums, int k) {
        int n = nums.length, count = gcd(n, k);
        for (int i = 0; i < count; i++) {
            int start = i, temp = nums[start];
            do {
                nums[start] = nums[(start - k % n + n) % n];
                start = (start - k % n + n) % n;
            } while (start != i);
            nums[(start + k % n) % n] = temp;
        }
    }

    public int gcd(int x, int y) {
        return y > 0 ? gcd(y, x % y) : x;
    }
}
