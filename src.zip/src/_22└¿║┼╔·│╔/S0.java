package _22括号生成;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    List<String> res = new ArrayList<>();

    public List<String> generateParenthesis(int n) {
        recall(n, 0, new StringBuilder(16));
        return res;
    }

    public void recall(int n, int t, StringBuilder sb) {
        if (t == n) {
            String temp = new String(sb);
            if (!res.contains(temp)) res.add(temp);
            return;
        }
        int index = Math.max(sb.indexOf(")"), 0);
        for (int i = 0; i < t; i++) {
            sb.insert(index, "()");
            recall(n, t + 1, sb);
            sb.delete(index, index + 2);
            index = sb.indexOf(")", index + 1);
        }
        sb.append("()");
        recall(n, t + 1, sb);
        sb.delete(2 * t, 2 * t + 2);
    }
}
