package _22括号生成;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    List<String> res = new ArrayList<>();

    public List<String> generateParenthesis(int n) {
        dfs(n, n, new StringBuilder(2 * n), n);
        return res;
    }

    public void dfs(int l, int r, StringBuilder sb, int n) {
        if (l == 0 && r == 0) {
            res.add(new String(sb));
            return;
        }
        if (l > 0) {
            sb.append('(');
            dfs(l - 1, r, sb, n);
            sb.deleteCharAt(2 * n - l - r);
        }
        if (r > l) {
            sb.append(')');
            dfs(l, r - 1, sb, n);
            sb.deleteCharAt(2 * n - l - r);
        }
    }
}
