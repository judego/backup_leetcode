package _22括号生成;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S1 s0 = new S1();
        List<String> list = s0.generateParenthesis(2);
    }
}
