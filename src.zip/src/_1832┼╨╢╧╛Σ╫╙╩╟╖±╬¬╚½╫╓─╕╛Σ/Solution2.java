package _1832判断句子是否为全字母句;

/**
 * @author wen
 * @version 1.0
 */
public class Solution2 {
    public boolean checkIfPangram(String sentence) {
        if (sentence.length() < 26) return false;
        int res = 0, i = 0;
        while (res != 67108863 && i < sentence.length()) {
            res |= 1 << sentence.charAt(i) - 'a';
            i++;
        }
        return res == 67108863;
    }
}
