package _1832判断句子是否为全字母句;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public boolean checkIfPangram(String sentence) {
        if (sentence.length() < 26) return false;
        boolean[] a = new boolean[26];
        char[] b = sentence.toCharArray();
        int i = 0, j = 0;
        while (j < 26 && i < b.length) {
            if (a[b[i] - 'a'] == false) {
                a[b[i] - 'a'] = true;
                i++;
                j++;
            } else i++;
        }
        return j == 26;
    }
}
