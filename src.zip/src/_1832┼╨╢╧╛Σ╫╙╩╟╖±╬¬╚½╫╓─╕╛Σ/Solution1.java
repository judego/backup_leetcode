package _1832判断句子是否为全字母句;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public boolean checkIfPangram(String sentence) {
        boolean[] a = new boolean[26];
        int i = 0, j = 0;
        while (j < 26 && i < sentence.length()) {
            if (a[sentence.charAt(i) - 'a'] == false) {
                a[sentence.charAt(i) - 'a'] = true;
                i++;
                j++;
            } else i++;
        }
        return j == 26;
    }
}
