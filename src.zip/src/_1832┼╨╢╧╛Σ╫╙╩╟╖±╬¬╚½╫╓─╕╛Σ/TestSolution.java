package _1832判断句子是否为全字母句;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution2 solution0 = new Solution2();
        solution0.checkIfPangram("ahequickbrownfoxjumpsoverthelazydog");
    }
}
