package _11盛最多水的容器;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int maxArea(int[] height) {
        int res = 0, l = 0, r = height.length - 1;
        while (l < r) {
            res = height[l] > height[r] ?
                    Math.max(res, (r - l) * height[r--]) :
                    Math.max(res, (r - l) * height[l++]);
        }
        return res;
    }
}
