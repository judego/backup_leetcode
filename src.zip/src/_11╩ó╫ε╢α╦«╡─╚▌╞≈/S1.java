package _11盛最多水的容器;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int maxArea(int[] height) {
        int res = 0, l = 0, r = height.length - 1;
        while (l < r) {
            int h = Math.min(height[l], height[r]);
            res = Math.max(h * (r - l), res);
            while (l < r && height[r] <= h) r--;
            while (l < r && height[l] <= h) l++;

        }
        return res;
    }
}
