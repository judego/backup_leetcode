package _11盛最多水的容器;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] arr = {1,8,6,2,5,4,8,3,7};
        int a = s0.maxArea(arr);
    }
}
