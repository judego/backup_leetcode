package _56合并区间;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 * 暂时写不出来，好像要兰布达表达式；
 */
public class Solution0 {
    public int[][] merge(int[][] intervals) {
        List<Integer[]> list = new ArrayList<>();
        int left = 0, right = 0;
        while (right <= intervals.length - 1) {
            while (right < intervals.length - 1 && intervals[right + 1][0] >= intervals[right][1]) {
                right++;
            }
            int[] temp  = {intervals[left][0],intervals[right][1]};
        }
        return null;
    }
}
