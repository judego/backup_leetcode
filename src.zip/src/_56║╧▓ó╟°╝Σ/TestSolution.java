package _56合并区间;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        int[][] arr = {{1, 4}, {2, 3}};
        Solution1 solution1 = new Solution1();
        int[][] a = solution1.merge(arr);
    }
}
