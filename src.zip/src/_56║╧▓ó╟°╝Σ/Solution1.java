package _56合并区间;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int[][] merge(int[][] intervals) {
        if (intervals.length == 0) return new int[0][2];
        Arrays.sort(intervals, Comparator.comparingInt(o -> o[0]));
        LinkedList<int[]> list = new LinkedList<>();
        int l = intervals[0][0], r = intervals[0][1];
        for (int[] interval : intervals) {
            if (interval[0] > r) {
                list.add(new int[]{l, r});
                l = interval[0];
                r = interval[1];
            } else if (interval[1] > r) r = interval[1];
        }
        list.add(new int[]{l, r});
        return list.toArray(new int[list.size()][]);
    }
}
