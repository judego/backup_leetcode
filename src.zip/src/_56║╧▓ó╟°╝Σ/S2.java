package _56合并区间;

import java.util.*;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int[][] merge(int[][] intervals) {
        Arrays.sort(intervals, new Comparator<int[]>() {
            public int compare(int[] interval1, int[] interval2) {
                return interval1[0] - interval2[0];
            }
        });
        ArrayList<int[]> list = new ArrayList<>();
        int l = intervals[0][0], r = intervals[0][1];
        for (int[] interval : intervals) {
            if (interval[0] > r) {
                list.add(new int[]{l, r});
                l = interval[0];
                r = interval[1];
            } else if (interval[1] > r) r = interval[1];
        }
        list.add(new int[]{l, r});
        return list.toArray(new int[list.size()][]);
    }
}
