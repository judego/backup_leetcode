package _40组合总和II;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S2 s0 = new S2();
        int[] arr = {10,1,2,7,6,1,5};
        List<List<Integer>> res = s0.combinationSum2(arr, 8);
    }
}
