package _40组合总和II;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    List<List<Integer>> res = new ArrayList<>();
    int[] can;
    int target;

    public List<List<Integer>> combinationSum2(int[] candidates, int target) {
        Arrays.sort(candidates);
        this.can = candidates;
        this.target = target;
        dfs(0, 0, new ArrayList<>());
        return res;
    }

    public void dfs(int start, int sum, List<Integer> list) {
        if (sum == target) {
            res.add(new ArrayList<>(list));
            return;
        }
        for (int i = start; i < can.length && sum + can[i] <= target; i++) {
            if (start < i && can[i] == can[i - 1]) continue;
            list.add(can[i]);
            dfs(i + 1, sum + can[i], list);
            list.remove(list.size() - 1);
        }
    }
}
