package _40组合总和II;

import java.util.*;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    List<List<Integer>> res = new ArrayList<>();
    int[] can;
    int target;

    public List<List<Integer>> combinationSum2(int[] candidates, int target) {
        Arrays.sort(candidates);
        this.can = candidates;
        this.target = target;
        dfs(0, 0, new ArrayDeque<>());
        return res;
    }

    public void dfs(int start, int sum, Deque<Integer> list) {
        if (sum == target) {
            res.add(new ArrayList<>(list));
            return;
        }
        int i = start;
        while (i < can.length && sum + can[i] <= target) {
            list.add(can[i]);
            dfs(i + 1, sum + can[i], list);
            list.removeLast();
            while (++i != can.length && can[i] == can[i - 1]) ;
        }
    }
}
