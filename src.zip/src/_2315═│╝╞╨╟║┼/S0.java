package _2315统计星号;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int countAsterisks(String s) {
        int res = 0;
        boolean flag = true;
        for (char c : s.toCharArray()) {
            if (flag && c == '*') res++;
            else if (c == '|') flag = !flag;
        }
        return res;
    }
}
