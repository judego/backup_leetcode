package _1801积压订单中的订单总数;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int getNumberOfBacklogOrders(int[][] orders) {
        for (int[] order : orders) {

        }
        return 0;
    }
}
