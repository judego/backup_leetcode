package _25K个一组翻转链表;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}

public class Solution0 {
    public ListNode reverseKGroup(ListNode head, int k) {
        int num = 0;
        for (ListNode p1 = head; p1 != null && num < k; num++) {
            p1 = p1.next;
        }
        if (num < k) return head;
        ListNode p1 = head, p2 = null, p3;
        for (int i = 0; i < k; i++) {
            ListNode temp = p1.next;
            p1.next = p2;
            p2 = p1;
            p1 = temp;
        }
        p3 = p2;
        for (int i = 0; i < k - 1; i++) {
            p3 = p3.next;
        }
        p3.next = reverseKGroup(p1, k);
        return p2;
    }
}
