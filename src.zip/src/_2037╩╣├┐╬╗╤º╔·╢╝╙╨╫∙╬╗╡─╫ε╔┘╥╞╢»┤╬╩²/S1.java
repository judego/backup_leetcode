package _2037使每位学生都有座位的最少移动次数;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int minMovesToSeat(int[] seats, int[] students) {
        int res = 0, p1 = 0, p2 = p1, count = 0, n = seats.length;
        int[] a1 = new int[100], a2 = new int[100];
        for (int seat : seats) a1[seat - 1]++;
        for (int student : students) a2[student - 1]++;
        while (count < n) {
            while (a1[p1]-- == 0) p1++;
            while (a2[p2]-- == 0) p2++;
            count++;
            res += Math.abs(p1 - p2);
        }
        return res;
    }
}
