package _1780判断一个数字是否可以表示成三的幂的和;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
}
