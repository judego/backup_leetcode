package _1760袋子里最少数目的球;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        int[] arr = {1};
        S0 s0 = new S0();
        int res = s0.minimumSize(arr, 1);
/*
        boolean flag = false;
        for (int man = 1; man < 20; man++) {
            int woman = 20 - man;
            for (int woman_pregnant = 1; woman_pregnant <= woman;
                 woman_pregnant++) {
                int woman_sick = woman - woman_pregnant, man_sick = woman_sick;
                if (man_sick + woman_sick - woman_pregnant == 3 &&
                        woman_pregnant * 2 + woman - woman_pregnant +
                                man_sick * 2 + woman_sick * 2 + man - man_sick +
                                woman - woman_sick == 49) {
                    System.out.println("\t男：" + man + "\t女：" + woman +
                            "\t男阳：" + man_sick + "\t男阴：" + (man - man_sick)
                            + "\t女阳：" + woman_sick + "\t女阴：" + (woman -
                            woman_sick) + "\t女怀孕：" + woman_pregnant);
                    flag = true;
                }
            }
        }
        if (!flag) System.out.println("无解");
*/
    }
}
