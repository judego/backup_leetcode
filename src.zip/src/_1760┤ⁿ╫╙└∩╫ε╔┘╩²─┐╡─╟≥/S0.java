package _1760袋子里最少数目的球;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int minimumSize(int[] nums, int maxOperations) {
        int l = 1, r = Arrays.stream(nums).max().getAsInt();
        while (l <= r) {
            int middle = (l + r) / 2;
            long mo = 0;
            for (int num : nums) {
                mo += (num - 1) / middle;
            }
            if (mo <= maxOperations) r = middle - 1;
            else l = middle + 1;
        }
        return l;
    }
}
