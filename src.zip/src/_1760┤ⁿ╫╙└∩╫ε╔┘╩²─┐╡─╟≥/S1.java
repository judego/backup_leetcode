package _1760袋子里最少数目的球;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
}
