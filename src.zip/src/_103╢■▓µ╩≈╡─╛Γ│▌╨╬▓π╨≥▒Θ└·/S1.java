package _103二叉树的锯齿形层序遍历;

import java.util.*;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public List<List<Integer>> zigzagLevelOrder(TreeNode root) {
        List<List<Integer>> res = new ArrayList<>();
        if (root == null) return res;
        Queue<TreeNode> stack = new LinkedList<>();
        stack.add(root);
        boolean isOdd = true;
        while (!stack.isEmpty()) {
            Deque<Integer> lever = new LinkedList<>();
            int len = stack.size();
            for (int i = 0; i < len; i++) {
                TreeNode temp = stack.poll();
                if (isOdd) lever.addLast(temp.val);
                else lever.addFirst(temp.val);
                if (temp.left != null) stack.add(temp.left);
                if (temp.right != null) stack.add(temp.right);
            }
            res.add(new ArrayList<>(lever));
            isOdd = !isOdd;
        }
        return res;
    }
}
