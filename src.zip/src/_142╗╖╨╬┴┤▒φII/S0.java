package _142环形链表II;

/**
 * @author wen
 * @version 1.0
 */
class ListNode {
    int val;
    ListNode next;

    ListNode(int x) {
        val = x;
        next = null;
    }
}

public class S0 {
    public ListNode detectCycle(ListNode head) {
        boolean flag = true;
        ListNode f = head, l = f;
        while (f != null && f.next != null) {
            f = f.next.next;
            l = l.next;
            if (f == l) {
                for (f = head; f != l; f = f.next, l = l.next) {
                }
                return f;
            }
        }
        return null;
    }
}
