package _34在排序数组中查找元素的第一个和最后一个位置;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 5, 6, 6, 8};
        S0 s0 = new S0();
        int s = s0.find(a, 6, true);
    }
}
