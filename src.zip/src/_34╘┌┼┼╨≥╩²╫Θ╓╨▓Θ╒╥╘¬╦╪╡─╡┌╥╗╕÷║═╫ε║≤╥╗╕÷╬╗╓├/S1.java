package _34在排序数组中查找元素的第一个和最后一个位置;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int[] searchRange(int[] nums, int target) {
        int[] res = new int[2];
        res[0] = find(nums, target, true);
        res[1] = find(nums, target, false) - 1;
        if (res[0] > res[1]) return new int[]{-1, -1};
        return res;
    }

    public int find(int[] nums, int target, boolean flag) {
        int l = 0, r = nums.length - 1;
        while (l <= r) {
            int m = l + (r - l) / 2;
            if ((flag && nums[m] >= target) || (!flag && nums[m] > target)) r = m - 1;
            else l = m + 1;
        }
        return l;
    }
}
