package _20有效地括号;

/**
 * @author wen
 * @version 1.0
 */
public class Try {
    public static void main(String[] args) {
        Solution0 solution = new Solution0();
        boolean a = solution.isValid("()");
    }
}
