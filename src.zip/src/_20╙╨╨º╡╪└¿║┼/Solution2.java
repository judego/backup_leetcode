package _20有效地括号;

import java.util.ArrayList;

/**
 * @author wen
 * @version 1.0
 */
public class Solution2 {
    public static boolean isValid(String s) {
        ArrayList<Character> t = new ArrayList<>();
        for (int i = 0; i < s.length(); i++) {
            t.add(s.charAt(i));
        }
        int size = t.size();
        for (int i = 0; i < size / 2; i++) {
            for (int j = 0; j < t.size() - 1; j++) {
                if (t.get(j) - t.get(j + 1) == -1 ||
                        t.get(j) - t.get(j + 1) == -2) {
                    t.remove(j);
                    t.remove(j);
                    break;
                }
            }
        }
        return t.size() == 0;
    }
}