package _20有效地括号;

import java.util.Stack;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public boolean isValid(String s) {
        Stack<Character> a = new Stack<>();
        for (char c : s.toCharArray()) {
            if (c == '(') {
                a.push(')');
            } else if (c == '[') {
                a.push(']');
            } else if (c == '{') {
                a.push('}');
            } else if (a.isEmpty() || c != a.pop()) {//这里虽然是判断，但是a弹出去了
                return false;
            }
        }
        return a.isEmpty();
    }
}
