package _1138字母板上的路径;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        String res = new S0() {
        }.alphabetBoardPath("zdz"
        );
    }
}
