package _1138字母板上的路径;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String alphabetBoardPath(String target) {
        StringBuilder sb = new StringBuilder();
        int x = 0, y = 0;
        for (char s : target.toCharArray()) {
            int r = (s - 'a') / 5, c = (s - 'a') % 5;
            while (r < x) {
                x--;
                sb.append('U');
            }
            while (c < y) {
                y--;
                sb.append('L');
            }
            while (r > x) {
                x++;
                sb.append('D');
            }
            while (c > y) {
                y++;
                sb.append('R');
            }
            sb.append('!');
        }
        return new String(sb);
    }
}
