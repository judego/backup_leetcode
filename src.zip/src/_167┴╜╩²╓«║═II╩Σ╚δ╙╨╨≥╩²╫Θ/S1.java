package _167两数之和II输入有序数组;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
}
