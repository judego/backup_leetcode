package _199二叉树的右视图;

import java.util.LinkedList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    List<Integer> res = new LinkedList<>();
    public List<Integer> rightSideView(TreeNode root) {
        dfs(0, root);
        return res;
    }
    public void dfs(int floor, TreeNode root) {
        if (root == null) return;
        if (res.size() <= floor) res.add(root.val);
        dfs(floor + 1, root.right);
        dfs(floor + 1, root.left);
    }
}
