package _199二叉树的右视图;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode() {
    }

    TreeNode(int val) {
        this.val = val;
    }

    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}

public class T {
    public static void main(String[] args) {
        TreeNode n5 = new TreeNode(5);
        TreeNode n4 = new TreeNode(4);
        TreeNode n2 = new TreeNode(2, null, n5);
        TreeNode n3 = new TreeNode(3, null, n4);
        TreeNode n1 = new TreeNode(1, n2, n3);
        List<Integer> res = new S0(){}.rightSideView(n1);
    }
}
