package _461汉明距离;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int hammingDistance(int x, int y) {
        int n = x ^ y, res = 0;
        while (n != 0) {
            n &= (n - 1);
            res++;
        }
        return res;
    }
}
