package _461汉明距离;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int hammingDistance(int x, int y) {
        int n = x ^ y;
        int res = n >= 0 ? 0 : 1;
        n = n & 2147483647;
        for (int i = 0; i < 32; i++) {
            if (n % 2 == 1) res++;
            n >>= 1;
        }
        return res;
    }
}
