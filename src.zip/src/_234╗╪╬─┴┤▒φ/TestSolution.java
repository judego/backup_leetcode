package _234回文链表;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        ListNode e = new ListNode(0);
        ListNode d = new ListNode(1,e);
        ListNode c = new ListNode(2,d);
        ListNode b = new ListNode(1,c);
        ListNode a = new ListNode(0,b);
        Solution0 solution0 = new Solution0();
        boolean r = solution0.isPalindrome(e);
    }
}
