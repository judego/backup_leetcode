package _234回文链表;

import java.util.Stack;

/**
 * @author wen
 * @version 1.0
 * 用快慢指针，区别无非就是栈实现还是反转链表实现
 */
class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}

public class Solution0 {
    public boolean isPalindrome(ListNode head) {
        ListNode top = new ListNode(0, head), fast = top, low = top;
        Stack<ListNode> stack = new Stack<>();
        while (!(fast == null || fast.next == null)) {
            low = low.next;
            stack.push(low);
            fast = fast.next.next;
        }
        low = low.next;
        if (fast == null) stack.pop();
        while (!(stack.isEmpty())) {
            if (stack.pop().val != low.val) {
                return false;
            }
            low = low.next;
        }
        return true;
    }
}
