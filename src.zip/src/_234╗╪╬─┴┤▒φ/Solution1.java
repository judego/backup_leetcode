package _234回文链表;

import java.util.ArrayList;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public boolean isPalindrome(ListNode head) {
        ListNode top = new ListNode(0, head), fast = top, low = top;
        ArrayList<Integer> al = new ArrayList<>();
        while (!(fast == null || fast.next == null)) {
            low = low.next;
            al.add(low.val);
            fast = fast.next.next;
        }
        Integer[] arr = al.toArray(new Integer[al.size()]);//这里转成数组有点技巧
        int cur = arr.length - 1;
        if (fast == null) cur--;
        low = low.next;
        for (; cur >= 0; cur--) {
            if (arr[cur] != low.val) {
                return false;
            }
            low = low.next;
        }
        return true;
    }
}
