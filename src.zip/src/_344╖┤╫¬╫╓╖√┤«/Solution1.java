package _344反转字符串;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public void reverseString(char[] s) {
        int p1 = 0, p2 = s.length - 1;
        char temp;
        while (p1 < p2) {
            temp = s[p1];
            s[p1] = s[p2];
            s[p2] = temp;
            p1++;
            p2--;
        }
    }
}
