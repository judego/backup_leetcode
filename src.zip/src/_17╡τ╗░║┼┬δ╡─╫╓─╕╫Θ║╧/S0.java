package _17电话号码的字母组合;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public List<String> letterCombinations(String digits) {
        if (digits.equals("")) return new ArrayList<>();
        List<String> res = new ArrayList<>();
        recall(digits, res, new StringBuilder(4), 0);
        return res;
    }

    public void recall(String digits, List<String> res, StringBuilder sb, int l) {
        if (l == digits.length()) {
            res.add(new String(sb));
            return;
        }
        char c = digits.charAt(l);
        char add = start(c);
        int times = len(c);
        for (int i = 0; i < times; i++, add++) {
            sb.append(add);
            recall(digits, res, sb, l + 1);
            sb.deleteCharAt(l);
        }
    }

    public char start(char c) {
        if (c < '8') return (char) ('a' + 3 * (c - '2'));
        if (c == '8') return 't';
        else return 'w';
    }

    public int len(char c) {
        if (c == '7' || c == '9') return 4;
        else return 3;
    }
}
