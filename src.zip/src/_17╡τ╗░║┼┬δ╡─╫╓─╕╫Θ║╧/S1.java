package _17电话号码的字母组合;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    HashMap<Character, String> map = new HashMap<Character, String>() {{
        put('2', "abc");
        put('3', "def");
        put('4', "ghi");
        put('5', "jkl");
        put('6', "mno");
        put('7', "pqrs");
        put('8', "tuv");
        put('9', "wxyz");
    }};

    public List<String> letterCombinations(String digits) {
        if (digits.equals("")) return new ArrayList<>();
        List<String> res = new ArrayList<>();
        recall(digits, res, new StringBuilder(4), 0);
        return res;
    }

    public void recall(String digits, List<String> res, StringBuilder sb, int l) {
        if (l == digits.length()) {
            res.add(new String(sb));
            return;
        }
        char[] temp = map.get(digits.charAt(l)).toCharArray();
        for (char c : temp) {
            sb.append(c);
            recall(digits, res, sb, l + 1);
            sb.deleteCharAt(l);
        }
    }
}
