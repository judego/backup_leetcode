package _119.杨辉三角II;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S1 s0 = new S1();
        List<Integer> list = s0.getRow(5);
    }
}
