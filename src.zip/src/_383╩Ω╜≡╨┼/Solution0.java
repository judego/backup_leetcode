package _383赎金信;

/**
 * @author wen
 * @version 1.0
 * 写错了
 */
public class Solution0 {
    public boolean canConstruct(String ransomNote, String magazine) {
        if (ransomNote.length() > magazine.length()) return false;
        for (int i = 0; i < magazine.length() - ransomNote.length() + 1; i++) {
            if (ransomNote.charAt(i) == magazine.charAt(i)) {
                for (int j = 1; j < ransomNote.length(); j++) {
                    if (ransomNote.charAt(i + j) != magazine.charAt(i + j)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }
}
