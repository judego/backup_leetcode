package _383赎金信;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution0 solution0 = new Solution0();
        boolean a = solution0.canConstruct("aa", "aab");
        int[] arr = new int[2];
        arr[0] = 3;
        int temp = arr[0];
        temp++;
    }
}
