package _21合并两个有序链表;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
        ListNode head = new ListNode();
        ListNode cur = head;
        ListNode cur1 = list1;
        ListNode cur2 = list2;
        int num = -1;
        while (!(cur1 == null && cur2 == null)) {
            if (cur1 == null) num = 0;
            if (cur2 == null) num = 1;
            if (cur1 != null && cur2 != null) {
                if (cur1.val <= cur2.val) num = 1;
                if (cur1.val > cur2.val) num = 0;
            }
            ListNode temp;
            switch (num) {
                case 0:
                    temp = cur2.next;
                    cur.next = cur2;
                    cur2.next = null;
                    cur2 = temp;
                    cur = cur.next;
                    break;
                case 1:
                    temp = cur1.next;
                    cur.next = cur1;
                    cur1.next = null;
                    cur1 = temp;
                    cur = cur.next;
                    break;
                default:
                    System.out.println("不属于以上四种");
            }
        }
        return head.next;
    }
}

class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}
