package _21合并两个有序链表;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        ListNode b = new ListNode(3);
        ListNode a = new ListNode(-9, b);
        ListNode B = new ListNode(7);
        ListNode A = new ListNode(5, B);
        Solution0 solution0 = new Solution0();
        ListNode d = solution0.mergeTwoLists(a, A);
    }
}
