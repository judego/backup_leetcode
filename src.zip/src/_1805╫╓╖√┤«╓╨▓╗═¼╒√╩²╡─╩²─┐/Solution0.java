package _1805字符串中不同整数的数目;

import java.util.HashSet;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int numDifferentIntegers(String word) {
        HashSet<String> hs = new HashSet<>();
        StringBuffer sb = new StringBuffer();
        char[] arr = word.toCharArray();
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] >= '0' && arr[i] <= '9') {
                sb.append(arr[i]);
                if (i == arr.length - 1 || !(arr[i + 1] >= '0'
                        && arr[i + 1] <= '9')) {
                    while (sb.length() >= 1 && sb.charAt(0) == '0')
                        sb.delete(0, 1);
                    hs.add(sb.toString());
                    sb.delete(0, sb.length());
                }
            }
        }
        return hs.size();
    }
}
