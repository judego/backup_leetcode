package _1819序列中不同最大公约数的数目;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int countDifferentSubsequenceGCDs(int[] nums) {
        int max = Arrays.stream(nums).max().getAsInt(), res = 0;
        boolean[] hash = new boolean[max + 1];
        for (int i : nums) hash[i] = true;
        for (int i = 1; i <= max; i++) {
            int g = 0;
            for (int j = i; j <= max && g != i; j += i) {
                if (hash[j]) g = gcd(g, j);
            }
            if (g == i) res++;
        }
        return res;
    }

    public int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }
}
