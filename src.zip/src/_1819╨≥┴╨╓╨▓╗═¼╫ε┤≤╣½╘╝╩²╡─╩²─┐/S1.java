package _1819序列中不同最大公约数的数目;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int countDifferentSubsequenceGCDs(int[] nums) {
        int max = Arrays.stream(nums).max().getAsInt(), res = 0;
        boolean[] hash = new boolean[max + 1];
        for (int i : nums)
            if (!hash[i]) {
                hash[i] = true;
                res++;
            }
        for (int i = 1; i <= max / 3; i++) {
            if (hash[i]) continue;
            int g = 0;
            for (int j = i * 2; j <= max; j += i) {
                if (hash[j]) {
                    g = gcd(g, j);
                    if (g == i) {
                        res++;
                        break;
                    }
                }
            }
        }
        return res;
    }

    public int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }
}
