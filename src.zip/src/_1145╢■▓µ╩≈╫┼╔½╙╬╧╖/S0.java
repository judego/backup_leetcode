package _1145二叉树着色游戏;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public boolean btreeGameWinningMove(TreeNode root, int n, int x) {
        TreeNode nx = find(root, x);
        int num1 = count(nx.left);
        if (num1 > n / 2) return true;
        int num2 = count(nx.right);
        if (num2 > n / 2) return true;
        if (num1 + num2 + 1 <= n / 2) return true;
        return false;

    }
    public int count(TreeNode root) {
        if (root == null) return 0;
        return count(root.left) + count(root.right) + 1;
    }
    public TreeNode find(TreeNode root, int x) {
        if (root == null) return null;
        else if (root.val == x) return root;
        else {
            TreeNode n1 = find(root.left, x);
            if (n1 != null) return n1;
            TreeNode n2 = find(root.right, x);
            if (n2 != null) return n2;
        }
        return null;
    }}
