package _338比特位计数;

/**
 * @author wen
 * @version 1.0
 * 解法一
 */
public class S1 {
    public int[] countBits(int n) {
        int[] res = new int[n + 1];
        int highBit = 0;
        for (int i = 1; i < n + 1; i++) {
            if ((i & (i - 1)) == 0) highBit = i;
            res[i] = res[i - highBit] + 1;
        }
        return res;
    }
}
