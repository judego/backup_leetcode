package _338比特位计数;

/**
 * @author wen
 * @version 1.0
 * 暴力算法
 */
public class S0 {
    public int[] countBits(int n) {
        int[] res = new int[n + 1];
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j < 17; j++) {
                res[i] += (i >> j) & 1;
            }
        }
        return res;
    }
}
