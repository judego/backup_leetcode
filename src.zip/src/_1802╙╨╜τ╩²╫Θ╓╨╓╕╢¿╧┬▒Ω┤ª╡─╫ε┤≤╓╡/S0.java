package _1802有界数组中指定下标处的最大值;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    int n, index, maxSum;

    public int maxValue(int n, int index, int maxSum) {
        this.n = n;
        this.index = index;
        this.maxSum = maxSum;
        int l = 1, r = maxSum - n + 1;
        while (l <= r) {
            int m = l + (r - l) / 2;
            if (check(m)) l = m + 1;
            else r = m - 1;
        }
        return l - 1;
    }

    public boolean check(long m) {
        long sum1, sum2;
        if (m > index + 1) sum1 = (2 * m - index - 1) * index / 2;
        else sum1 = (m - 1) * m / 2 + index - m + 1;
        if (m >= n - index) sum2 = (2 * m - n + index) * (n - index - 1) / 2;
        else sum2 = (m - 1) * m / 2 + n - index - m;
        return sum1 + sum2 + m <= maxSum;
    }
}
