package _1802有界数组中指定下标处的最大值;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.maxValue(4,0,4);
    }
}
