package _36有效的数独;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public boolean isValidSudoku(char[][] board) {
        return true;
    }

    public String[][] reverse(String[][] arr) {
        String[][] res = new String[arr[0].length][arr.length];
        for (int i = 0; i < arr[0].length; i++) {
            for (int j = 0; j < arr.length; j++) {
                res[j][i] = arr[i][j];
            }
        }
        return res;
    }

    public String[][] toNine(String[][] arr) {
        String[][] res = new String[arr[0].length][arr.length];
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                res[i][j] = arr[(i / 3) * 3 + j / 3][(i % 3) * 3 + j % 3];
            }
        }
        return res;
    }
}
