package _36有效的数独;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public boolean isValidSudoku(char[][] board) {
        return check(board) && check(reverse(board)) && check(toNine(board));
    }

    public char[][] reverse(char[][] arr) {
        char[][] res = new char[arr[0].length][arr.length];
        for (int i = 0; i < arr[0].length; i++) {
            for (int j = 0; j < arr.length; j++) {
                res[j][i] = arr[i][j];
            }
        }
        return res;
    }

    public char[][] toNine(char[][] arr) {
        char[][] res = new char[arr[0].length][arr.length];
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                res[i][j] = arr[(i / 3) * 3 + j / 3][(i % 3) * 3 + j % 3];
            }
        }
        return res;
    }

    public boolean check(char[][] arr) {
        int[][] test = new int[9][9];
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (arr[i][j] == 46) continue;
                test[i][arr[i][j] - 49]++;
                if (test[i][arr[i][j] - 49] > 1)
                    return false;
            }
        }
        return true;
    }
}
