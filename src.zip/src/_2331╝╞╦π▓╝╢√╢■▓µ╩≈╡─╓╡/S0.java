package _2331计算布尔二叉树的值;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public boolean evaluateTree(TreeNode root) {
        if (root.val == 2) return evaluateTree(root.left) || evaluateTree(root.right);
        else if (root.val == 3) return evaluateTree(root.left) && evaluateTree(root.right);
        else if (root.val == 0) return false;
        return true;
    }
}
