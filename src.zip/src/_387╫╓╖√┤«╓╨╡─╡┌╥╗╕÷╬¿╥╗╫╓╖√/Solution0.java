package _387字符串中的第一个唯一字符;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int firstUniqChar(String s) {
        int[] arr = new int['z' - 'a' + 1];
        for (int i = 0; i < s.length(); i++) {
            arr[s.charAt(i) - 'a']++;
        }
        for (int i = 0; i < s.length(); i++) {
            if (arr[s.charAt(i) - 'a'] == 1) return i;
        }
        return -1;
    }
}
