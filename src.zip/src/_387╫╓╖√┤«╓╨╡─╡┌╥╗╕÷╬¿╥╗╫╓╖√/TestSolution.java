package _387字符串中的第一个唯一字符;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution0 solution0 = new Solution0();
        int a = solution0.firstUniqChar("leetcode");
    }
}
