package _2309兼具大小写的最好英文字母;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public String greatestLetter(String s) {
        int low = 0, up = 0;
        for (char c : s.toCharArray()) {
            if (c >= 'a') low |= (1 << (c - 'a'));
            else up |= (1 << (c - 'A'));
        }
        low &= up;
        for (int i = 25; i >= 0; i--) {
            if (((1 << i) & low) != 0) return (char)('A' + i) + "";
        }
        return "";
    }
}
