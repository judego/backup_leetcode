package _2309兼具大小写的最好英文字母;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public String greatestLetter(String s) {
        for (char c = 'Z'; c >= 'A'; c--) {
            if (s.indexOf(c) > -1 && s.indexOf(c + 32) > -1) return String.valueOf(c);
        }
        return "";
    }
}
