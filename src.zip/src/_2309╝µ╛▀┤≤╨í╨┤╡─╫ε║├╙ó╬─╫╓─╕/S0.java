package _2309兼具大小写的最好英文字母;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String greatestLetter(String s) {
        boolean[] arr = new boolean[52];
        for (char c : s.toCharArray()) {
            if (c >= 'a')
                arr[c - 'a'] = true;
            else arr[c - 'A' + 26] = true;
        }
        for (int i = 51; i >= 26; i--) {
            if (arr[i] && arr[i - 26]) return (char) (i + 'A' - 26) + "";
        }
        return "";
    }
}
