package _118杨辉三角;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
}
