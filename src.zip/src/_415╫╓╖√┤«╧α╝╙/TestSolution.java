package _415字符串相加;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        String d = s0.addStrings("456", "77");
    }
}
