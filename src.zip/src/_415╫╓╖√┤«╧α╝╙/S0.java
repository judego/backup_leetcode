package _415字符串相加;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String addStrings(String num1, String num2) {
        if (num2.length() > num1.length()) return addStrings(num2, num1);
        int[] res = new int[num1.length() + 1];
        for (int p1 = num1.length() - 1, p2 = num2.length() - 1; p1 >= 0; p1--, p2--) {
            if (p2 >= 0) res[p1 + 1] += num1.charAt(p1) + num2.charAt(p2) - 96;
            else res[p1 + 1] += num1.charAt(p1) - 48;
            if (res[p1 + 1] > 9) {
                res[p1]++;
                res[p1 + 1] -= 10;
            }
        }
        StringBuffer so = new StringBuffer();
        for (int i = res[0] == 0 ? 1 : 0; i < res.length; i++) {
            so.append(res[i]);
        }
        return so.toString();
    }
}
