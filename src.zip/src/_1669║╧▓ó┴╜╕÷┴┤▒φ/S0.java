package _1669合并两个链表;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public ListNode mergeInBetween(ListNode list1, int a, int b, ListNode list2) {
        ListNode n1 = list1, n2;
        int count = 0;
        while (count++ < a - 1) n1 = n1.next;
        n2 = n1;
        while (count++ < b + 2) n2 = n2.next;
        n1.next = list2;
        while (n1.next != null) n1 = n1.next;
        n1.next = n2;
        return list1;
    }
}
