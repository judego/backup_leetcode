package _1669合并两个链表;

/**
 * @author wen
 * @version 1.0
 */
class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}

public class T {
    public static void main(String[] args) {

    }
}
