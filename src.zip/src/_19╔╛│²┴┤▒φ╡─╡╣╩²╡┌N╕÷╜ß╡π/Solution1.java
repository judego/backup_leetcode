package _19删除链表的倒数第N个结点;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
}
