package _19删除链表的倒数第N个结点;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        ListNode node2 = new ListNode(0);
        ListNode node1 = new ListNode(0,node2);
        Solution0 solution0 = new Solution0();
        System.out.println(solution0.getLength(node1));
        solution0.removeNthFromEnd(node1,2);
        System.out.println(solution0.getLength(node1));
    }
}
