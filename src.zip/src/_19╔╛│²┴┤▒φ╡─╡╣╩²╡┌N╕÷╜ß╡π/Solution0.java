package _19删除链表的倒数第N个结点;

/**
 * @author wen
 * @version 1.0
 */

class Solution0 {
    public ListNode removeNthFromEnd(ListNode head, int n) {
        ListNode cur;
        ListNode pre = head;
        ListNode temp = new ListNode();
        int size = getLength(head);
        if (size == 1) return null;
        if (size == n) {
            cur = head.next;
            head.next = null;
            return cur;
        }
        for (int i = 0; i < size - n - 1; i++) {
            pre = pre.next;
        }
        cur = pre.next;
        temp.next = cur;
        pre.next = null;
        if (cur.next != null) {
            cur = cur.next;
            pre.next = cur;
        }
        return head;
    }

    public int getLength(ListNode head) {
        if (head.next == null) {
            return 1;
        }
        int result = 1;
        ListNode cur = head;
        while (cur.next != null) {
            cur = cur.next;
            result++;
        }
        return result;
    }
}

class ListNode {
    int val;
    ListNode next;

    ListNode() {
    }

    ListNode(int val) {
        this.val = val;
    }

    ListNode(int val, ListNode next) {
        this.val = val;
        this.next = next;
    }
}
