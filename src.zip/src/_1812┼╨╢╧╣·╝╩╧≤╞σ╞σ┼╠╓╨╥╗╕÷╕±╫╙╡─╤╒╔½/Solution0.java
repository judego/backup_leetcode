package _1812判断国际象棋棋盘中一个格子的颜色;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public boolean squareIsWhite(String coordinates) {
        return (coordinates.charAt(0) + coordinates.charAt(1)) % 2 == 1;
    }
}
