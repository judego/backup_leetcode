package _1812判断国际象棋棋盘中一个格子的颜色;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
}
