package _1664生成平衡数组的方案数;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int waysToMakeFair(int[] nums) {
        int res = 0, sum = 0;
        for (int i = 0; i < nums.length; i += 2) sum += nums[i];
        for (int i = 1; i < nums.length; i += 2) sum -= nums[i];
        for (int i = 0; i < nums.length; i++) {
            if ((i & 1) == 0) {
                if (nums[i] == sum) res++;
                sum -= 2 * nums[i];
            } else {
                if (-nums[i] == sum) res++;
                sum += 2 * nums[i];
            }
        }
        return res;
    }
}
