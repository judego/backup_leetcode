package _1664生成平衡数组的方案数;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        int[] arr = {1,1,1};
        int res = new S0(){}.waysToMakeFair(arr);
    }
}
