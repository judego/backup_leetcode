package _1664生成平衡数组的方案数;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int waysToMakeFair(int[] nums) {
        int sum1 = 0, sum2 = 0, sum3 = 0, sum4 = 0, res = 0;
        for (int i = 0; i < nums.length; i++) {
            if (i % 2 == 0) sum4 += nums[i];
            else sum2 += nums[i];
        }
        for (int i = 0; i < nums.length; i++) {
            if (i % 2 == 0) {
                if (nums[i] == sum1 * 2 - sum2 - sum3 * 2 + sum4) res++;
                sum3 += nums[i];
            } else {
                if (-nums[i] == sum1 * 2 - sum2 - sum3 * 2 + sum4) res++;
                sum1 += nums[i];
            }
        }
        return res;
    }
}
