package _1792最大平均通过率;

import java.util.PriorityQueue;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public double maxAverageRatio(int[][] classes, int extraStudents) {
        PriorityQueue<double[]> pq = new PriorityQueue<>((a, b) -> {
            return Double.compare((b[1] - b[0]) / (b[1] + 1) / b[1], (a[1] - a[0]) / (a[1] + 1) / a[1]);
        });
        for (int[] aClass : classes) {
            pq.add(new double[]{aClass[0], aClass[1]});
        }
        while (extraStudents-- > 0) {
            double[] temp = pq.poll();
            temp[0]++;
            temp[1]++;
            pq.add(temp);
        }
        double res = 0;
        while (!pq.isEmpty()) {
            double[] temp = pq.poll();
            res += temp[0] / temp[1];
        }
        return res / classes.length;
    }
}
