package _1两数之和;

import java.util.HashMap;
import java.util.HashSet;

/**
 * @author wen
 * @version 1.0
 */
public class Main {
    public static void main(String[] args) {
        HashSet<Integer> hs = new HashSet<>();
        hs.add(1);
        System.out.println(hs.contains(1));
        HashMap<Integer, Integer> ob = new HashMap<>();
        ob.put(1,1);
        boolean a = ob.containsKey(1);
        ob.put(1,2);
    }
}