package _51N皇后;

import org.omg.CORBA.MARSHAL;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    List<List<String>> res = new ArrayList<>();
    int[] c;
    int n;
    boolean[] used;

    public List<List<String>> solveNQueens(int n) {
        this.n = n;
        c = new int[n];
        used = new boolean[n];
        backtrack(0);
        return res;
    }

    public void backtrack(int cur) {
        if (cur == n) {
            convert();
            return;
        }
        for (int i = 0; i < n; i++) {
            if (!used[i] && check(cur, i)) {
                c[cur] = i;
                used[i] = true;
                backtrack(cur + 1);
                used[i] = false;
            }
        }
    }

    public boolean check(int cur, int num) {
        for (int i = 0; i < cur; i++) {
            if (cur - i == Math.abs(num - c[i])) return false;
        }
        return true;
    }

    public void convert() {
        List<String> list = new ArrayList<>(n);
        for (int i : c) {
            char[] temp = new char[n];
            Arrays.fill(temp, '.');
            temp[i] = 'Q';
            list.add(new String(temp));
        }
        res.add(list);
    }
}
