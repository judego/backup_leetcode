package _51N皇后;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        List<List<String >> res = s0.solveNQueens(4);
    }
}
