package _1604警告一小时内使用相同员工卡大于等于三次的人;

import java.util.*;

/**
 * @author wen
 * @version 1.0
 */
public class Sw {
    public List<String> alertNames(String[] keyName, String[] keyTime) {
        List<String> res = new LinkedList<>();
        HashMap<String, List<Integer>> mp = new HashMap<>();
        for (int i = 0; i < keyName.length; i++) {
            String t = keyTime[i];
            int time = (t.charAt(0) - '0') * 600 + (t.charAt(1) - '0') * 60 +
                    (t.charAt(3) - '0') * 10 + (t.charAt(4) - '0');
            List<Integer> list = mp.get(keyName[i]);
            if (list != null) list.add(time);
            else {
                list = new ArrayList<>(keyTime[i].length());
                list.add(time);
                mp.put(keyName[i], list);
            }
        }
        for (Map.Entry<String, List<Integer>> entry : mp.entrySet()) {
            List<Integer> list = entry.getValue();
            Integer[] time = list.toArray(new Integer[list.size()]);
            Arrays.sort(time);
            for (int i = 2; i < time.length; i++)
                if (time[i] - time[i - 2] <= 60) {
                    res.add(entry.getKey());
                    break;
                }
        }
        res.sort(String::compareTo);
        return res;
    }
}
