package _1604警告一小时内使用相同员工卡大于等于三次的人;

import java.util.*;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {

    public List<String> alertNames(String[] keyName, String[] keyTime) {
        List<String> res = new LinkedList<>();
        HashMap<String, List<Integer>> mp = new HashMap<>();
        for (int i = 0; i < keyName.length; i++) {
            List<Integer> time = mp.get(keyName[i]);
            if (time != null) time.add(convert(keyTime[i]));
            else {
                time = new ArrayList<>(keyTime[i].length());
                time.add(convert(keyTime[i]));
                mp.put(keyName[i], time);
            }
        }
        for (Map.Entry<String, List<Integer>> entry : mp.entrySet()) {
            List<Integer> list = entry.getValue();
            Integer[] a = list.toArray(new Integer[list.size()]);
            if (check(a)) res.add(entry.getKey());
        }
        res.sort(String::compareTo);
        return res;
    }

    public int convert(String time) {
        return (time.charAt(0) - '0') * 600 + (time.charAt(1) - '0') * 60 +
                (time.charAt(3) - '0') * 10 + (time.charAt(4) - '0');
    }

    public boolean check(Integer[] time) {
        if (time.length < 2) return false;
        Arrays.sort(time);
        for (int i = 2; i < time.length; i++)
            if (time[i] - time[i - 2] <= 60) return true;
        return false;
    }
}

