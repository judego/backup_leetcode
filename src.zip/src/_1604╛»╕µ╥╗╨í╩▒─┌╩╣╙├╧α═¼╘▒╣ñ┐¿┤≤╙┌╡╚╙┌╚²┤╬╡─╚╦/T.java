package _1604警告一小时内使用相同员工卡大于等于三次的人;

import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        String[] a = {"a","a","a","a","a","a","a","b","b","b","b","b","b","b",
                "c","c","c","c","c","c","c","c","c"};
        String[] b = {"00:37","11:24","14:35","21:25","15:48","20:28","07:30",
                "09:26","10:32","20:10","19:26","08:13","01:08","15:49","02:34",
                "06:48","04:33","07:18","00:05","06:44","13:33","04:12","03:54"};
        List<String> res = new Sw(){}.alertNames(a, b);
    }
}
