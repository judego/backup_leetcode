package _1604警告一小时内使用相同员工卡大于等于三次的人;

import java.sql.DataTruncation;
import java.util.*;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public List<String> alertNames(String[] keyName, String[] keyTime) {
        List<String> res = new LinkedList<>();
        HashMap<String, List<String>> mp = new HashMap<>();
        for (int i = 0; i < keyName.length; i++) {
            List<String> time = mp.get(keyName[i]);
            if (time != null) time.add(keyTime[i]);
            else {
                time = new ArrayList<>(keyTime[i].length());
                time.add(keyTime[i]);
                mp.put(keyName[i], time);
            }
        }
        for (Map.Entry<String, List<String>> entry : mp.entrySet()) {
            List<String> list = entry.getValue();
            String[] a = list.toArray(new String[list.size()]);
            if (check(a)) res.add(entry.getKey());
        }
        res.sort(String::compareTo);
        return res;
    }

    public boolean check(String[] time) {
        if (time.length < 2) return false;
        Arrays.sort(time);
        for (int i = 2; i < time.length; i++) {
            String a = time[i - 2];
            String b = time[i];
            int hour = (b.charAt(0) - a.charAt(0)) * 10 + b.charAt(1) - a.charAt(1);
            int min = ((b.charAt(3) - a.charAt(3)) * 10 + (b.charAt(4) - a.charAt(4)));
            if (hour == 0 || (hour == 1 && min <= 0)) return true;
        }
        return false;
    }
}
