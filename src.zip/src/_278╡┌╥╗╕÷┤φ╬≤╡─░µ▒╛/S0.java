package _278第一个错误的版本;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int firstBadVersion(int n) {
        long l = 0, r = n;
        while (l <= r) {
            long m = (l + r) / 2;
            if ((int)m < 1702766719) l = m + 1;
            else r = m - 1;
        }
        return (int) l;
    }
}
