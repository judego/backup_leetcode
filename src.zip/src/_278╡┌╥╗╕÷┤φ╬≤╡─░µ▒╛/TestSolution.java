package _278第一个错误的版本;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.firstBadVersion(2126753390);
    }
}
