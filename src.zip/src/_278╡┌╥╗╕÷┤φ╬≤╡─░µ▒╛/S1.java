package _278第一个错误的版本;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int firstBadVersion(int n) {
        int l = 0, r = n;
        while (l <= r) {
            int m = l + (r - l) / 2;
            if (m < 1702766719) l = m + 1;
            else r = m - 1;
        }
        return l;
    }
}
