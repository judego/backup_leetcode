package _49字母异位词分组;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public List<List<String>> groupAnagrams(String[] strs) {
        HashMap<String, List<String>> map = new HashMap<>();
        for (String str : strs) {
            byte[] arr = new byte[26];
            for (char c : str.toCharArray()) {
                arr[c - 'a']++;
            }
            String key = new String(arr);
            map.putIfAbsent(key,new ArrayList<>());
            map.get(key).add(str);
        }
        return new ArrayList<List<String>>(map.values());
    }
}
