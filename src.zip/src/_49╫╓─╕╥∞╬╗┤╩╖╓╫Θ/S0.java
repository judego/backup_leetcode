package _49字母异位词分组;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public List<List<String>> groupAnagrams(String[] strs) {
        HashMap<String, List<String>> map = new HashMap<>();
        for (String str : strs) {
            StringBuilder sb = new StringBuilder();
            byte[] arr = new byte[26];
            for (char c : str.toCharArray()) {
                arr[c - 'a']++;
            }
            for (int i = 0; i < 26; i++) {
                while (arr[i] != 0) {
                    sb.append(i + 'a');
                    arr[i]--;
                }
            }
            List<String> list = map.getOrDefault(sb.toString(), new ArrayList<>());
            list.add(str);
            map.put(sb.toString(), list);
        }
        return new ArrayList<List<String>>(map.values());
    }
}
