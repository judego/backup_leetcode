package _116填充每个节点的下一个右侧节点指针;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Node n7 = new Node(7);
        Node n6 = new Node(6);
        Node n5 = new Node(5);
        Node n4 = new Node(4);
        Node n3 = new Node(3, n6, n7, null);
        Node n2 = new Node(2, n4, n5, null);
        Node n1 = new Node(1, n2, n3, null);
        S1 s0 = new S1();
        Node d = s0.connect(n1);
    }
}
