package _116填充每个节点的下一个右侧节点指针;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public Node connect(Node root) {
        if (root == null) return root;
        if (root.left != null) {
            root.left.next = root.right;
            if (root.next != null) root.right.next = root.next.left;
        }
        connect(root.left);
        connect(root.right);
        return root;
    }
}
