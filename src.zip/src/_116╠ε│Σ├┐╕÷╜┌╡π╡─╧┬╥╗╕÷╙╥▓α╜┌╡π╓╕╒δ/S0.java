package _116填充每个节点的下一个右侧节点指针;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author wen
 * @version 1.0
 */
class Node {
    public int val;
    public Node left;
    public Node right;
    public Node next;

    public Node() {
    }

    public Node(int _val) {
        val = _val;
    }

    public Node(int _val, Node _left, Node _right, Node _next) {
        val = _val;
        left = _left;
        right = _right;
        next = _next;
    }
};

public class S0 {
    public Node connect(Node root) {
        if (root == null) return root;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            int n = queue.size();
            Node pre = null;
            for (int i = 0; i < n; i++) {
                Node temp = queue.poll();
                if (pre != null) pre.next = temp.left;
                if (temp.left != null) {
                    temp.left.next = temp.right;
                    queue.add(temp.left);
                    queue.add(temp.right);
                    pre = temp.right;
                }
            }
            if (pre != null) pre.next = null;
        }
        return root;
    }
}
