package _116填充每个节点的下一个右侧节点指针;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public Node connect(Node root) {
        if (root == null) return root;
        Node first = root;
        while (first.left != null) {
            Node cur = first;
            while (cur != null) {
                cur.left.next = cur.right;
                if (cur.next != null) cur.right.next = cur.next.left;
                cur = cur.next;
            }
            first = first.left;
        }
        return root;
    }
}
