package _35搜索插入位置;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        int[] arr = {1, 3, 5, 6};
        Solution0 solution0 = new Solution0();
        int f = solution0.searchInsert(arr, 5);
    }
}
