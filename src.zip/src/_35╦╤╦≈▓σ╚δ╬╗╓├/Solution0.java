package _35搜索插入位置;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int searchInsert(int[] nums, int target) {
        int l = 0, r = nums.length - 1;
        while (l <= r) {
            int i = (r + l) / 2;
            if (nums[i] < target) l = i + 1;
            else if (nums[i] >= target) r = i - 1;
            else return l;
        }
        return l;
    }
}
