package _35搜索插入位置;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
}
