package _347前K个高频元素;


import java.util.HashMap;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int[] topKFrequent(int[] nums, int k) {
        HashMap<Integer, Integer> map = new HashMap<>();
        int min = 0, count = 0, n = 1;
        for (int num : nums) {
            if (num == n) count++;
            else if (count > min) {
                min = count;
                map.put(n,count);
                count = 1;
                n = num;
            }
        }
        if (count > min) {
            map.put(n,count);}
        return nums;
    }
}
