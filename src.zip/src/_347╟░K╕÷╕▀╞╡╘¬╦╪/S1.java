package _347前K个高频元素;

import java.util.*;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int[] topKFrequent(int[] nums, int k) {
        HashMap<Integer, Integer> mp = new HashMap<>();
        for (int num : nums) {
            mp.put(num, mp.getOrDefault(num, 0) + 1);
        }
        PriorityQueue<int[]> queue = new PriorityQueue<>(new Comparator<int[]>() {
            @Override
            public int compare(int[] o1, int[] o2) {
                return o1[1] - o2[1];
            }
        });
        for (Map.Entry<Integer, Integer> entry : mp.entrySet()) {
            int num = entry.getKey(), frequency = entry.getValue();
            if (queue.size() < k) queue.add(new int[]{num, frequency});
            else if (frequency > queue.peek()[1]) {
                queue.poll();
                queue.add(new int[]{num, frequency});
            }
        }
        int[] res = new int[k];
        for (int i = 0; i < k; i++) {
            res[i] = queue.poll()[0];
        }
        return res;
    }
}
