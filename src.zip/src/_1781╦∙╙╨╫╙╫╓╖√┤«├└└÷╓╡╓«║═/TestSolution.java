package _1781所有子字符串美丽值之和;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution1 solution0 = new Solution1();
        String s = "aabcbaa";
        int d = solution0.beautySum(s);
    }
}
