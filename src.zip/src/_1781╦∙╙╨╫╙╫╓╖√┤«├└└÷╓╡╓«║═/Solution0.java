package _1781所有子字符串美丽值之和;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int beautySum(String s) {
        if (s.length() < 3) return 0;
        int[] latter1;
        char[] latter2 = s.toCharArray();
        int max, min, left = 0, right, res = 0;
        while (left < latter2.length) {
            min = max = -1;
            right = left;
            latter1 = new int[26];
            while (right < latter2.length) {
                if (max == -1) {
                    max = min = latter2[right] - 'a';
                    latter1[latter2[right] - 'a']++;
                } else {
                    latter1[latter2[right] - 'a']++;
                    if (latter1[latter2[right] - 'a'] > latter1[max]) max = latter2[right] - 'a';
                    if (latter1[latter2[right] - 'a'] == 1) min = latter2[right] - 'a';
                    else if (latter2[right] == min + 'a') min = find(latter1);
                    if (max != min) res += latter1[max] - latter1[min];
                }
                right++;
            }
            left++;
        }
        return res;
    }

    public int find(int[] arr) {
        int min = Integer.MAX_VALUE, index = -1;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != 0 && arr[i] < min) {
                min = arr[i];
                index = i;
            }
        }
        return index;
    }
}
