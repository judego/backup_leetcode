package _1781所有子字符串美丽值之和;

/**
 * @author wen
 * @version 1.0
 */
public class Solution2 {
    public int beautySum(String s) {
        if (s.length() < 3) return 0;
        int[] latter1;
        char[] latter2 = s.toCharArray();
        int max, min, left = 0, right, res = 0;
        while (left < latter2.length) {
            latter1 = new int[26];
            min = max = latter2[left] - 'a';
            latter1[latter2[left] - 'a']++;
            right = left + 1;
            while (right < latter2.length) {
                int temp = ++latter1[latter2[right] - 'a'];
                if (temp > latter1[max]) max = latter2[right] - 'a';
                if (temp == 1) min = latter2[right] - 'a';
                else if (latter2[right] == min + 'a') {
                    for (int i = 0; i < latter1.length; i++) {
                        if (latter1[i] != 0 && latter1[i] < latter1[min]) {
                            min = i;
                        }
                    }
                }
                if (max != min) res += latter1[max] - latter1[min];
                right++;
            }
            left++;
        }
        return res;
    }
}
