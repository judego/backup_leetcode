package _3无重复字符的最长子串;

import java.util.HashSet;
import java.util.Set;

/**
 * @author wen
 * @version 1.0
 */
public class Solution2 {
    public int lengthOfLongestSubstring(String s) {
        char[] arr = s.toCharArray();
        int max = 0;
        for (int i = 0; i < arr.length; i++) {
            Set<Character> set = new HashSet<>();
            for (int j = i; j < arr.length && !set.contains(arr[j]); j++) {
                set.add(arr[j]);
            }
            max = Math.max(max, set.size());
        }
        return max;
    }
}
