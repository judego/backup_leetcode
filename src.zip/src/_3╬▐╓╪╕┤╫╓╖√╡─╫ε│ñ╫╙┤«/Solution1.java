package _3无重复字符的最长子串;


import java.util.HashSet;
import java.util.Set;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int lengthOfLongestSubstring(String s) {
        if (s.isEmpty()) {
            return 0;
        } else if (s.length() == 1) {
            return 1;
        }
        int max = 0;
        for (int i = 0; i != s.length() - 1; i++) {
            String temp = "";
            for (int j = i + 2; check(temp) && j != s.length() + 1; j++) {
                temp = s.substring(i, j);
            }
            max = Math.max(max, check(temp) ? temp.length() : temp.length() - 1);
        }
        return max;
    }

    public boolean check(String s) {
        if (s.isEmpty()) return true;
        char[] arr = s.toCharArray();
        Set<Character> set = new HashSet<>();
        for (int i = 0; i < arr.length; i++) {
            if (set.contains(arr[i])) return false;
            set.add(arr[i]);
        }
        return true;
    }
}
