package _3无重复字符的最长子串;

import java.util.HashMap;
import java.util.Map;

/**
 * @author wen
 * @version 1.0
 * 先转换成数组，内存小很多
 */
public class Solution4 {
    public int lengthOfLongestSubstring(String s) {
        char[] arr = s.toCharArray();
        Map<Character, Integer> map = new HashMap<>();
        int left = 0, max = 0;
        for (int i = 0; i < arr.length; i++) {
            if (map.containsKey(arr[i])) {
                left = Math.max(left, map.get(arr[i]) + 1);
            }
            map.put(arr[i], i);
            max = Math.max(max, i - left + 1);
        }
        return max;
    }
}
