package _3无重复字符的最长子串;

import java.util.HashMap;
import java.util.Map;

/**
 * @author wen
 * @version 1.0
 */
public class Solution5 {
    public int lengthOfLongestSubstring(String s) {
        int[] last = new int[128];
        for (int i = 0; i < last.length; i++) last[i] = -1;
        int max = 0, left = 0;
        for (int right = 0; right < s.length(); right++) {
            left = Math.max(left, last[s.charAt(right)] + 1);
            last[s.charAt(right)] = right;
            max = Math.max(max, right - left + 1);
        }
        return max;
    }
/*
    public int lengthOfLongestSubstring(String s) {
        char[] arr = s.toCharArray();
        int[] last = new int[128];
        for (int i = 0; i < last.length; i++) last[i] = -1;
        int max = 0, left = 0;
        for (int right = 0; right < arr.length; right++) {
            left = Math.max(left, last[arr[right]] + 1);
            last[arr[right]] = right;
            max = Math.max(max, right - left + 1);
        }
        return max;
    }
*/
}
