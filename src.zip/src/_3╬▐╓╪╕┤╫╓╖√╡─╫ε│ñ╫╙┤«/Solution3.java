package _3无重复字符的最长子串;

import java.util.HashSet;
import java.util.Set;

/**
 * @author wen
 * @version 1.0
 * 写错了
 */
public class Solution3 {
    public int lengthOfLongestSubstring(String s) {
        char[] arr = s.toCharArray();
        int max = 0, left = max;
        for (int i = 0; i < arr.length; i++) {
            Set<Character> set = new HashSet<>();
            for (int j = i; j < arr.length; ) {
                set.add(arr[j]);
                if (j == arr.length - 1) {
                    break;
                }
                if (set.contains(arr[++j])) {
                    i = j - 1;
                    break;
                }
            }
            max = Math.max(max, set.size());
        }
        return max;
    }
}
