package _3无重复字符的最长子串;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution5 solution0 = new Solution5();
        int a = solution0.lengthOfLongestSubstring(" ");
    }
}
