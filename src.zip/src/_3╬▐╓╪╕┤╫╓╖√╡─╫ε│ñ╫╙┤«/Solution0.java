package _3无重复字符的最长子串;

import java.util.HashSet;
import java.util.Set;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int lengthOfLongestSubstring(String s) {
        char[] arr = s.toCharArray();
        Set<Character> set = new HashSet<>();
        int max = 0;
        for (int i = 0; i < arr.length; i++) {
            if (!set.contains(arr[i])) {
                set.add(arr[i]);
                continue;
            }
            max = Math.max(max, set.size());
            if (i != arr.length - 1) {
                set.clear();
                set.add(arr[i]);
            }
        }
        return Math.max(max, set.size());
    }
}
