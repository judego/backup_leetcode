package _169多数元素;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public int majorityElement(int[] nums) {
        for (int gap = nums.length / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < nums.length; i++) {
                int j = i;
                int temp = nums[j];
                if (nums[j] < nums[j - gap]) {
                    while (j >= gap && temp < nums[j - gap]) {
                        nums[j] = nums[j - gap];
                        j -= gap;
                    }
                    nums[j] = temp;
                }
            }

        }
        return nums[nums.length / 2];
    }
}
//public class Solution1 {
//    public int majorityElement(int[] nums) {
//        for (int gap = nums.length / 2; gap > 0; gap /= 2) {
//            //改变gap并分组
//            for (int i = gap; i < nums.length; i++) {
//                //暂存现在的值
//                int j = i;
//                //j要时刻变动
//                int temp = nums[j];
//                //采用插入法把每组排好
//                if (nums[j] < nums[j - gap]) {
//                    //移动的条件
//                    while (j >= gap && temp < nums[j - gap]) {
//                        //移动终止的条件
//                        nums[j] = nums[j - gap];
//                        j -= gap;
//                        //往前跳
//                    }
//                    nums[j] = temp;
//                }
//            }
//
//        }
//        return nums[nums.length / 2];
//    }
//}
