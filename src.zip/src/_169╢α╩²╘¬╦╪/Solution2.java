package _169多数元素;

/**
 * @author wen
 * @version 1.0
 */
public class Solution2 {
    public int majorityElement(int[] nums) {
        int count = 0;
        int win = 0;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] == win) {
                count++;
            } else if (nums[i] != win && count == 0) {
                win = nums[i];
                count++;
            } else {
                count--;
            }
        }
        return win;
    }
}
