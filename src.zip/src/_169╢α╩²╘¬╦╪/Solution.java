package _169多数元素;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class Solution {
    public int majorityElement(int[] nums) {
        Arrays.sort(nums);
        return nums[nums.length / 2];
    }
}
