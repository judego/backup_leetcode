package _2341数组能形成多少数对;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int[] numberOfPairs(int[] nums) {
        int[] arr = new int[101];
        int count = 0;
        for (int n : nums) {
            if (++arr[n] % 2 == 0) count++;
        }
        return new int[]{count, nums.length - 2 * count};
    }
}
