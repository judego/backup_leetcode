package _2303计算应缴税款总额;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public double calculateTax(int[][] brackets, int income) {
        double res = 0;
        int i = 0, temp = 0;
        while (true) {
            int upper = brackets[i][0], percent = brackets[i][1];
            if (income > upper) res += (upper - temp) * percent * 0.01;
            else {
                res += (income - temp) * percent * 0.01;
                break;
            }
            temp = upper;
            i++;
        }
        return res;
    }
}
