package _2303计算应缴税款总额;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[][] arr = {{3, 50}, {7, 10}, {12, 25}};
        double res = s0.calculateTax(arr, 10);
    }
}
