package _2042检查句子中的数字是否递增;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public boolean areNumbersAscending(String s) {
        char[] arr = s.toCharArray();
        int cur = 0, temp = -1;
        boolean flag = false;
        for (char c : arr) {
            if (flag && c == 32) {
                flag = false;
                if (cur <= temp) return false;
                else {
                    temp = cur;
                    cur = 0;
                }
            } else if (c < 58 && c > 47) {
                cur = cur * 10 + c - '0';
                flag = true;
            }
        }
        if (flag && cur <= temp) return false;
        return true;
    }
}
