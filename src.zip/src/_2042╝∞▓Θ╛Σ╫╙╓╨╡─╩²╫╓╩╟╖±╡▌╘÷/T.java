package _2042检查句子中的数字是否递增;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        boolean a = s0.areNumbersAscending("hello world 5 x 5");
    }
}
