package _2347最好的扑克手牌;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String bestHand(int[] ranks, char[] suits) {
        if (suits[1] == suits[0] && suits[2] == suits[0] && suits[3] == suits[0] && suits[4] == suits[0])
            return "Flush";
        Arrays.sort(ranks);
        if (ranks[1] == ranks[0] && ranks[2] == ranks[0] || ranks[2] == ranks[1] && ranks[3] == ranks[1] || ranks[3] == ranks[2] && ranks[4] == ranks[2])
            return "Three of a Kind";
        if (ranks[1] != ranks[0] && ranks[2] != ranks[1] && ranks[3] != ranks[2] && ranks[4] != ranks[3])
            return "High Card";
        else return "Pair";
    }
}
