package _2347最好的扑克手牌;

import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public String bestHand(int[] ranks, char[] suits) {
        if (suits[1] == suits[0] && suits[2] == suits[0] && suits[3] == suits[0] && suits[4] == suits[0])
            return "Flush";
        int[] temp = new int[13];
        boolean flag = false;
        for (int rank : ranks) {
            if (temp[rank - 1]++ == 1) flag = true;
            else if (temp[rank - 1]++ == 2) return "Three of a Kind";
        }
        return flag ? "Pair" : "High Card";
    }
}
