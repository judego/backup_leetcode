package _121.买卖股票的最佳时机;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public int maxProfit(int[] prices) {
        int max = 0;
        return 0;
    }
}
