package _2185统计包含给定前缀的字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int prefixCount(String[] words, String pref) {
        int res = 0;
        for (String s : words) if (s.startsWith(pref)) res++;
        return res;
    }
}
