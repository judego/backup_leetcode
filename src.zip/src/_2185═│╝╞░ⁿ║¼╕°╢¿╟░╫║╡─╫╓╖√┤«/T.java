package _2185统计包含给定前缀的字符串;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {

    }
}
