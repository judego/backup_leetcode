package _239滑动窗口最大值;

import org.junit.jupiter.api.Test;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    @Test
    public int[] maxSlidingWindow(int[] nums, int k) {
        int max;
        int index = 0;
        int[] arr = new int[nums.length - k + 1];
        for (int i = 0; i < nums.length - k + 1; i++) {
            if (i > 0 && index > i - 1) {
                if (nums[k + i - 1] >= arr[i - 1]) {
                    arr[i] = nums[k + i - 1];
                    index = k + i - 1;
                } else arr[i] = arr[i - 1];
                continue;
            }
            max = nums[i];
            for (int j = 0; j < k; j++) {
                if (nums[i + j] >= max) {
                    index = i + j;
                    max = nums[index];
                }
            }
            arr[i] = max;
        }
        return arr;
    }
}
