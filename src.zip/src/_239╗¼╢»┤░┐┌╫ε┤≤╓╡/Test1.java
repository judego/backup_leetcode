package _239滑动窗口最大值;

/**
 * @author wen
 * @version 1.0
 */
public class Test1 {
    public static void main(String[] args) {
        int[] a = {1, -1};
        int[] arr = new S2(){}.maxSlidingWindow(a, 1);
    }
}
