package _239滑动窗口最大值;

import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * @author wen
 * @version 1.0
 * 超时
 */
public class S1 {
    public int[] maxSlidingWindow(int[] nums, int k) {
        PriorityQueue<Integer> queue = new PriorityQueue<>(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o2 - o1;
            }
        });
        int[] res = new int[nums.length - k + 1];
        int i = -1;
        while (i < k - 1) queue.add(nums[++i]);
        while (i < nums.length - 1) {
            res[i - k + 1] = queue.peek();
            queue.remove(nums[i - k + 1]);
            queue.add(nums[++i]);
        }
        res[i - k + 1] = queue.peek();
        return res;
    }
}
