package _239滑动窗口最大值;

import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int[] maxSlidingWindow(int[] nums, int k) {
        PriorityQueue<int[]> queue = new PriorityQueue<>(new Comparator<int[]>() {
            @Override
            public int compare(int[] o1, int[] o2) {
                return o2[0] == o1[0] ? o2[1] - o1[1] : o2[0] - o1[0];
            }
        });
        int[] res = new int[nums.length - k + 1];
        int i = -1;
        while (i < k - 1) queue.add(new int[]{nums[++i], i});
        while (i < nums.length - 1) {
            res[i - k + 1] = queue.peek()[0];
            queue.add(new int[]{nums[++i], i});
            while (i - k >= queue.peek()[1]) queue.poll();
        }
        res[i - k + 1] = queue.peek()[0];
        return res;
    }
}
