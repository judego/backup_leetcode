package _53最大子数组和;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public int maxSubArray(int[] nums) {
        int sum = 0;
        int[] arr = new int[nums.length + 1];
        for (int i = 0; i < nums.length; i++) {
            sum += nums[i];
            arr[i + 1] = sum;
        }
        int min = arr[0];
        int result = arr[1];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] - min > result) {
                result = arr[i] - min;
            }
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        return result;
    }
}
