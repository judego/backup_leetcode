package _53最大子数组和;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution0 solution0 = new Solution0();
        int[] arr = {-2,-1};
        int a = solution0.maxSubArray(arr);
    }
}
