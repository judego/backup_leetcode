package _231数字2的幂;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
}
