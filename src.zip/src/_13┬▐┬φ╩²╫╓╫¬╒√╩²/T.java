package _13罗马数字转整数;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        int res = new S0(){}.romanToInt("MCMXCIV");
    }
}
