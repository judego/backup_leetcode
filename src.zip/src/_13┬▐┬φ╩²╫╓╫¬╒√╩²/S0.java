package _13罗马数字转整数;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int romanToInt(String str) {
        int[] s = new int[str.length()];
        int i = 0, res = 0;
        for (char c : str.toCharArray()) {
            if (c == 'I') s[i++] = 1;
            else if (c == 'V') s[i++] = 5;
            else if (c == 'X') s[i++] = 10;
            else if (c == 'L') s[i++] = 50;
            else if (c == 'C') s[i++] = 100;
            else if (c == 'D') s[i++] = 500;
            else if (c == 'M') s[i++] = 1000;
        }
        for (i = 0; i < s.length - 1; i++) {
            if (s[i] < s[i + 1]) res -= s[i];
            else res += s[i];
        }
        return res + s[s.length - 1];
    }
}
