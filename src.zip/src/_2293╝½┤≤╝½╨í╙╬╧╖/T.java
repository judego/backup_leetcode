package _2293极大极小游戏;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int[] arr = {1, 3, 5, 2, 4, 8, 2, 2};
        int s = s0.minMaxGame(arr);
    }
}
