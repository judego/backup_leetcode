package _1663具有给定数值的最小字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String getSmallestString(int n, int k) {
        StringBuilder sb = new StringBuilder(n);
        while (n > 0) {
            for (int i = 1; i < 27; i++) {
                if (k - i <= (n - 1) * 26) {
                    sb.append((char)(i + 96));
                    k -= i;
                    break;
                }
            }
            n--;
        }
        return sb.toString();
    }
}
