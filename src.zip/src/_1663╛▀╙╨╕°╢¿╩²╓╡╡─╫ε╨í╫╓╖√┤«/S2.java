package _1663具有给定数值的最小字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public String getSmallestString(int n, int k) {
        char[] res = new char[n];
        int cur = 0;
        for (char c = 'a'; c <= 'z' && n > 0; c++) {
            int num = number(c - 96, n, k);
            if (num > 0) {
                n -= num;
                k -= num * (c - 96);
                while (num-- > 0) res[cur++] = c;
            }
        }
        return new String(res);
    }

    public int number(int i, int n, int k) {
        int l = 0, r = n;
        while (l <= r) {
            int m = (l + r) / 2;
            if (i * m + (n - m) * 26 >= k) l = m + 1;
            else r = m - 1;
        }
        return r;
    }
}
