package _1663具有给定数值的最小字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public String getSmallestString(int n, int k) {
        StringBuilder sb = new StringBuilder(n);
        for (char c = 'a'; c <= 'z'; c++) {
            int l = 0, r = n;
            while (l <= r) {
                int m = (l + r) / 2;
                if ((c - 96) * m + (n - m) * 26 >= k) l = m + 1;
                else r = m - 1;
            }
            n -= r;
            k -= r * (c - 96);
            l = 0;
            while (l < r) {
                sb.append(c);
                l++;
            }
        }
        return sb.toString();
    }
}
