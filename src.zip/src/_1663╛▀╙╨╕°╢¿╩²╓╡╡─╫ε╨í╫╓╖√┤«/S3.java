package _1663具有给定数值的最小字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S3 {
/*
    public String getSmallestString(int n, int k) {
        StringBuilder sb = new StringBuilder();
        k -= n;
        int x = k % 25, y = k / 25;
        if (x > 0) {
            sb.append("a".repeat(n - 1 - y)).append((char) ('a' + x));
        } else {
            sb.append("a".repeat(n - y));
        }
        sb.append("z".repeat(y));
        return sb.toString();
    }
*/
}
