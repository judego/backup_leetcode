package _1663具有给定数值的最小字符串;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        String res = new S2(){}.getSmallestString(5,73);
    }
}
