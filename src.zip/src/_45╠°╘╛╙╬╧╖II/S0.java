package _45跳跃游戏II;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int jump(int[] nums) {
        int step = 0;
        for (int l = 0, r = 0, temp = 0; l < nums.length - 1; l++) {
            r = Math.max(r, l + nums[l]);
            if (l == temp) {
                temp = r;
                step++;
            }
        }
        return step;
    }
}
