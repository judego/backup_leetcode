package _06从尾到头打印链表;

import java.util.Stack;

/**
 * @author wen
 * @version 1.0
 */
class Solution1 {
    public int[] reversePrint(ListNode head) {
        Stack<ListNode> stack = new Stack<>();
        ListNode cur = head;
        int count = 0;
        while (cur != null) {
            stack.push(cur);
            cur = cur.next;
            count++;
        }
        int[] arr = new int[count];
        for (int i = 0; i < count; i++) {
            arr[i] = stack.pop().val;
        }
        return arr;
    }
}
