package _191位1的个数;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S0 s0 = new S0();
        int a = s0.hammingWeight(0b11111111111111111111111111111101);
        System.out.println(~0b10000000000000000000000000000000);
    }
}
