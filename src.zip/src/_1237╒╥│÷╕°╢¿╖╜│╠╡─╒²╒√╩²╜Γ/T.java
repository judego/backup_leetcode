package _1237找出给定方程的正整数解;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {

    }
}
