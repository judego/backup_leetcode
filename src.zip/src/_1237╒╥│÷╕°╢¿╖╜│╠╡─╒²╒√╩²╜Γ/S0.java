package _1237找出给定方程的正整数解;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
class CustomFunction {
    // Returns f(x, y) for any given positive integers x and y.
    // Note that f(x, y) is increasing with respect to both x and y.
    // i.e. f(x, y) < f(x + 1, y), f(x, y) < f(x, y + 1)
    public int f(int x, int y) {
        return 0;
    }
}

public class S0 {
    public List<List<Integer>> findSolution(CustomFunction customfunction, int z) {
        List<List<Integer>> res = new LinkedList<>();
        for (int l = 1, r = 1000; l < 1001 && r > 0; l++) {
            while (r > 1 && customfunction.f(l, r) > z) r--;
            if (customfunction.f(l, r) == z) {
                final int x = l, y = r;
                res.add(new ArrayList<Integer>(2) {{
                    add(x);
                    add(y);
                }});
            }
        }
        return res;
    }
}
