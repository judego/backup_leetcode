package _448找到所有数组中消失的数字;

import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        Solution1 solution1 = new Solution1();
        int[] arr = {4, 3, 2, 7, 8, 2, 3, 1};
        List<Integer> d = solution1.findDisappearedNumbers(arr);
    }
}
