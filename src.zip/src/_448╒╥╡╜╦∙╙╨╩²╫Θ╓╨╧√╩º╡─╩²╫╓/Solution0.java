package _448找到所有数组中消失的数字;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 * 用集合的写法，感觉还是很复杂。
 */
public class Solution0 {
    public List<Integer> findDisappearedNumbers(int[] nums) {
        List<Integer> temp = new ArrayList<>();
        List<Integer> result = new ArrayList<>();
        Arrays.sort(nums);
        int max = nums[nums.length - 1];
        for (int i = 1; i < max + 1; i++) {
            temp.add(i);
        }
        for (int i = 0; i < nums.length; i++) {
            if (temp.contains(nums[i])) {
                temp.remove(nums[i] - 1);
                temp.add(nums[i] - 1, 0);
            }
        }
        for (Integer integer : temp) {
            if (!(integer.equals(0))) {
                result.add(integer);
            }
        }
        return result;
    }
}
