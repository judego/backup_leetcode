package _448找到所有数组中消失的数字;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class Solution1 {
    public List<Integer> findDisappearedNumbers(int[] nums) {
        List<Integer> result = new ArrayList<>();
        int[] arr = new int[nums.length];
        for (int num : nums) arr[num - 1] = 1;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == 0) {
                result.add(i + 1);
            }
        }
        return result;
    }
}
