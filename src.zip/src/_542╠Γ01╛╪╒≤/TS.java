package _542题01矩阵;

/**
 * @author wen
 * @version 1.0
 */
public class TS {
    public static void main(String[] args) {
        int[][] arr = {{0, 0, 0, 1}, {0, 1, 1, 0}, {1, 1, 1, 1}, {1, 1, 1, 1}};
        S0 s0 = new S0();
        int[][] a = s0.updateMatrix(arr);
    }
}
