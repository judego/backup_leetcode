package _542题01矩阵;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public int[][] updateMatrix(int[][] mat) {
        int row = mat.length, column = mat[0].length;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                if (mat[i][j] == 1) mat[i][j] = 10000;
            }
        }
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                if (mat[i][j] == 10000) {
                    if (i > 0) mat[i][j] = Math.min(mat[i - 1][j] + 1, mat[i][j]);
                    if (j > 0) mat[i][j] = Math.min(mat[i][j - 1] + 1, mat[i][j]);
                }
            }
        }
        for (int i = row - 1; i >= 0; i--) {
            for (int j = column - 1; j >= 0; j--) {
                if (mat[i][j] != 0) {
                    if (i < row - 1) mat[i][j] = Math.min(mat[i + 1][j] + 1, mat[i][j]);
                    if (j < column - 1) mat[i][j] = Math.min(mat[i][j + 1] + 1, mat[i][j]);
                }
            }
        }
        return mat;
    }
}
