package _238移动零;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author wen
 * @version 1.0
 */
class Solution {
    public void moveZeroes(int[] nums) {
        int index = Arrays.binarySearch(nums, 0);
        if (index != -1) {

        }
    }
}
