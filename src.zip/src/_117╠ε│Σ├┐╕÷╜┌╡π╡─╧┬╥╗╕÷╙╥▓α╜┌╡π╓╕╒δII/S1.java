package _117填充每个节点的下一个右侧节点指针II;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public Node connect(Node root) {
        if (root == null) return null;
        Node temp = new Node(0), cur = temp, res = root;
        while (root != null) {
            if (root.left != null) {
                cur.next = root.left;
                cur = cur.next;
            }
            if (root.right != null) {
                cur.next = root.right;
                cur = cur.next;
            }
            root = root.next;
            if (root == null) {
                root = temp.next;
                cur = temp;
                temp.next = null;
            }
        }
        return res;
    }
}
