package _117填充每个节点的下一个右侧节点指针II;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public Node connect(Node root) {
        if (root == null) return null;
        if (root.left != null && root.right != null) root.left.next = root.right;
        Node temp = root.next, n1 = null, n2 = null;
        if (root.right != null) n1 = root.right;
        else if (root.left != null) n1 = root.left;
        while (temp != null && n2 == null) {
            if (temp.left != null) n2 = temp.left;
            else if (temp.right != null) n2 = temp.right;
            temp = temp.next;
        }
        if (n1 != null && n2 != null) n1.next = n2;
        connect(root.right);
        connect(root.left);
        return root;
    }
}
