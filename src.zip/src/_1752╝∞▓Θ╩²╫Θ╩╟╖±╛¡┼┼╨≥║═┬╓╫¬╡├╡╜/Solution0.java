package _1752检查数组是否经排序和轮转得到;

/**
 * @author wen
 * @version 1.0
 */
public class Solution0 {
    public boolean check(int[] nums) {
        int[] arr = new int[nums.length];
        int index = -1;
        boolean flag = true;
        for (int i = 0; i < nums.length - 1; i++) {
            if (nums[i] - nums[i + 1] > 0) {
                index = i + 1;
            }
        }
        if (index == -1) {
            index = 0;
        }
        for (int i = 0; i < arr.length; i++) {
            arr[i] = nums[(i + index) % nums.length];
        }
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] - arr[i + 1] > 0) {
                flag = false;
            }
        }
        return flag;
    }
}
