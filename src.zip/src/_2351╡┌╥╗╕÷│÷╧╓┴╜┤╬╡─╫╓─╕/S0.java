package _2351第一个出现两次的字母;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public char repeatedCharacter(String s) {
        for (int i = 0, num = 0; i < 27; i++) {
            char a = s.charAt(i);
            int temp = 1 << (a - 97);
            if ((num & temp) != 0) return a;
            else num += temp;
        }
        return 'a';
    }
}
