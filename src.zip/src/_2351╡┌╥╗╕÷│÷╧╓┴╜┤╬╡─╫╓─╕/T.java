package _2351第一个出现两次的字母;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S0 s0 = new S0();
        char a = s0.repeatedCharacter("abcdd");
    }
}
