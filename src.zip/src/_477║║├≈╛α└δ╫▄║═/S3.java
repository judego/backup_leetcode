package _477汉明距离总和;

/**
 * @author wen
 * @version 1.0
 */
public class S3 {
    public int totalHammingDistance(int[] nums) {
        int res = 0, n = nums.length;
        for (int i = 0; i < 31; i++) {
            int count = 0;
            for (int num : nums) {
                if ((num & (1 << i)) != 0) count++;
            }
            res += count * (n - count);
        }
        return res;
    }
}
