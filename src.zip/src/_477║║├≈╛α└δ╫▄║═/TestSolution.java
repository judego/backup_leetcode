package _477汉明距离总和;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S4 s0 = new S4();
        int[] arr = {1,2,3};
        int a = s0.totalHammingDistance(arr);
        System.out.println(1<<0);
    }
}
