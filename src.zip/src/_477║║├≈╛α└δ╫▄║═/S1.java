package _477汉明距离总和;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public int totalHammingDistance(int[] nums) {
        int[] arr = new int[32];
        for (int num : nums) {
            for (int i = 0; i < 31; i++) {
                arr[i] += (num >> i) & 1;
            }
        }
        int res = 0, n = nums.length;
        for (int i : arr) {
            res += i * (n - i);
        }
        return res;
    }
}
