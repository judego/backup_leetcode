package _477汉明距离总和;

/**
 * @author wen
 * @version 1.0
 * 超时了
 */
public class S0 {
    public int totalHammingDistance(int[] nums) {
        int res = 0;
        for (short l = 0; l < nums.length - 1; l++) {
            for (short r = (short) (l + 1); r < nums.length; r++) {
                res += hammingDistance(nums[l], nums[r]);
            }
        }
        return res;
    }

    public int hammingDistance(int x, int y) {
        int n = x ^ y, res = 0;
        while (n != 0) {
            n &= (n - 1);
            res++;
        }
        return res;
    }
}
