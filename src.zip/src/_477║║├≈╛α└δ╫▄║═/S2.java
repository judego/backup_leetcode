package _477汉明距离总和;

/**
 * @author wen
 * @version 1.0
 */
public class S2 {
    public int totalHammingDistance(int[] nums) {
        int res = 0, n = nums.length;
        for (int i = 0; i < 30; i++) {
            int count = 0;
            for (int num : nums) {
                count += (num >> i) & 1;
            }
            res += count * (n - count);
        }
        return res;
    }
}
