package _52N皇后II;

/**
 * @author wen
 * @version 1.0
 */
public class T {
    public static void main(String[] args) {
        S1 s1 = new S1();
        int ad = s1.totalNQueens(1);
        for (int i = 1; i < 10; i++) {
            int temp = s1.totalNQueens(i);
            System.out.println("case " + i + ":return " + temp + ";");
        }
    }
}
