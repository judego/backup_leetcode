package _52N皇后II;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    int res = 0;
    int n;
    int[] c;
    boolean[] used;

    public int totalNQueens(int n) {
        c = new int[n];
        used = new boolean[n];
        this.n = n;
        backtrack(0);
        return res;
    }

    public void backtrack(int cur) {
        if (cur == n) {
            res++;
            return;
        }
        for (int i = 0; i < n; i++) {
            if (!used[i] && check(cur, i)) {
                c[cur] = i;
                used[i] = true;
                backtrack(cur + 1);
                used[i] = false;
            }
        }
    }

    public boolean check(int cur, int num) {
        for (int i = 0; i < cur; i++) {
            if (cur - i == Math.abs(num - c[i])) return false;
        }
        return true;
    }
}
