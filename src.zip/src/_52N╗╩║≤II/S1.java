package _52N皇后II;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    int res = 0;

    public int totalNQueens(int n) {
        backtrack(0, n, new int[n], new boolean[n]);
        return res;
    }

    public void backtrack(int cur, int n, int[] c, boolean[] used) {
        if (cur == n) {
            res++;
            return;
        }
        for (int i = 0; i < n; i++) {
            if (used[i]) continue;
            boolean flag = true;
            for (int j = 0; j < cur; j++) {
                if (cur - j == Math.abs(i - c[j])) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                c[cur] = i;
                used[i] = true;
                backtrack(cur + 1, n, c, used);
                used[i] = false;
            }
        }
    }
}
