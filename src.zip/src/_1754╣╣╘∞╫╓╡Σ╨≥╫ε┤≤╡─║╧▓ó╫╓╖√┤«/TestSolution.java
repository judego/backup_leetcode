package _1754构造字典序最大的合并字符串;

/**
 * @author wen
 * @version 1.0
 */
public class TestSolution {
    public static void main(String[] args) {
        S1 s0 = new S1();
        String a = s0.largestMerge("abcabc", "abdcaba");
    }
}
