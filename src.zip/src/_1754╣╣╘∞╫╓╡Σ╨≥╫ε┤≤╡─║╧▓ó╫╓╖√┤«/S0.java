package _1754构造字典序最大的合并字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S0 {
    public String largestMerge(String word1, String word2) {
        StringBuilder res = new StringBuilder();
        int l1 = 0, l2 = l1, n = word1.length() + word2.length();
        while (res.length() < n) {
            if (word1.charAt(l1) > word2.charAt(l2)) {
                res.append(word1.charAt(l1));
                l1++;
            } else if (word1.charAt(l1) < word2.charAt(l2)) {
                res.append(word2.charAt(l2));
                l2++;
            } else {
                int r1 = l1, r2 = l2;
                boolean flag = false;
                while (r1 < word1.length() && r2 < word2.length()) {
                    r1++;
                    r2++;
                    if (r1 == word1.length()) {
                        flag = true;
                        break;
                    } else if (r2 == word2.length()) break;
                    if (word1.charAt(r1) > word2.charAt(r2)) {
                        break;
                    } else if (word1.charAt(r1) < word2.charAt(r2)) {
                        flag = true;
                        break;
                    }
                }
                if (flag) {
                    res.append(word2.charAt(l2));
                    l2++;
                } else {
                    res.append(word1.charAt(l1));
                    l1++;
                }
            }
            if (l2 == word2.length()) {
                res.append(word1.substring(l1));
            } else if (l1 == word1.length()) {
                res.append(word2.substring(l2));
            }
        }
        return res.toString();
    }
}