package _1754构造字典序最大的合并字符串;

/**
 * @author wen
 * @version 1.0
 */
public class S1 {
    public String largestMerge(String word1, String word2) {
        char[] c1 = word1.toCharArray(), c2 = word2.toCharArray();
        int p1 = 0, p2 = p1, len1 = c1.length, len2 = c2.length;
        StringBuilder res = new StringBuilder();
        while (p1 < len1 && p2 < len2) {
            char w1 = c1[p1], w2 = c2[p2];
            if (w1 > w2) {
                res.append(w1);
                p1++;
            } else if (w1 < w2) {
                res.append(w2);
                p2++;
            } else {
                if (compare(c1, c2, p1, p2) > 0) {
                    res.append(w1);
                    p1++;
                } else {
                    res.append(w2);
                    p2++;
                }
            }
        }
        if (p1 < len1) res.append(word1.substring(p1));
        if (p2 < len2) res.append(word2.substring(p2));
        return res.toString();
    }

    public int compare(char[] c1, char[] c2, int p1, int p2) {
        int k = Math.min(c1.length - p1, c2.length - p2), count = 0;
        while (count < k) {
            char temp1 = c1[p1 + count], temp2 = c2[p2 + count];
            if (temp1 != temp2) return temp1 - temp2;
            count++;
        }
        return c1.length - p1 - c2.length + p2;
    }
}
